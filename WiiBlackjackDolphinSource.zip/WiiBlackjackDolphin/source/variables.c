#include "variables.h"

// Framebuffer and GX pointers
void *xfb = NULL;
GXRModeObj *rmode = NULL;

// Empty texture object
GXTexObj texObj;
TPLFile spriteTPL;

// Wiimote infrared data variable
ir_t ir;

// Gxconsole set position variables
int content_row = 1;
int content_col = 1;

// Define starting cash
int player_coins = 1000;
int high_score = 1000;

// Define bet current
int bet_current = 10;

// Define animation speed
int animation_speed = 15;	// 10 is fast, 15 is medium, 20 is slow

// Define card count
int card_count_toggle = 0;
int card_count_running = 0;
int once_count_2nd_dealer_card = 1;		//Only card count the 2nd dealer card once

// Define default number of decks
int num_of_decks = 2;
int top_card_of_deck = 103;

// Create the empty decks
Card deck_a[52];
Card deck_b[52];
Card deck_c[52];
Card deck_d[52];
Card deck[208];

// Create empty player and dealer hands 
Card player_cards[5];
Card dealer_cards[5]; 
Card split_a_cards[5];
Card split_b_cards[5];

int num_of_player_cards = 0;
int num_of_dealer_cards = 0;
int num_of_split_a_cards = 0;
int num_of_split_b_cards = 0;

int dealer_score = 0;
int player_score = 0;
int split_a_score = 0;
int split_b_score = 0;

bool double_down_flag = false;
bool double_down_split_a = false;
bool double_down_split_b = false;
bool triple_down_flag = false;
bool triple_down_split_a = false;
bool triple_down_split_b = false;
bool split_flag = false;
bool rotate_flag = false;
bool seven_flag = false;
bool insurance_flag = false;
