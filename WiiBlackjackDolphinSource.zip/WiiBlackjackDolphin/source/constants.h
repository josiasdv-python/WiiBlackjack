#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <stdio.h>

extern const int card_rect[];                                         
extern const int middle_rect[];
extern const int basic_rect[];
extern const int table_green_rect[];

extern const int dealer_rect_1[];
extern const int dealer_rect_2[];
extern const int dealer_rect_3[];
extern const int dealer_rect_4[];
extern const int dealer_rect_5[];
extern const int player_rect_1[];
extern const int player_rect_2[];
extern const int player_rect_3[];
extern const int player_rect_4[];
extern const int player_rect_5[];

extern const int player_split_1[];
extern const int player_split_2[];
extern const int player_split_3[];
extern const int player_split_4[];
extern const int player_split_5[];
extern const int player_split_6[];
extern const int player_split_7[];
extern const int player_split_8[];
extern const int player_split_9[];
extern const int player_split_10[];

extern const int stand_button_rect[];
extern const int hit_button_rect[];
extern const int double_button_rect[];
extern const int triple_button_rect[];
extern const int split_button_rect[];
extern const int bet10_button_rect[];
extern const int bet25_button_rect[];
extern const int bet50_button_rect[];
extern const int bet100_button_rect[];
extern const int bet250_button_rect[];
extern const int yes_button_rect[];
extern const int no_button_rect[];
extern const int new_button_rect[];
extern const int rules_button_rect[];
extern const int options_button_rect[];
extern const int about_button_rect[];
extern const int quit_button_rect[];
extern const int confirm_button_rect[];
extern const int default_button_rect[];
extern const int cancel_button_rect[];

extern const int deck1_circle[];
extern const int deck2_circle[];
extern const int deck3_circle[];
extern const int deck4_circle[];
extern const int slow_circle[];
extern const int medium_circle[];
extern const int fast_circle[];
extern const int on_circle[];
extern const int off_circle[];

extern const int pos_1button_rect[];
extern const int pos_2button_rect[];
extern const int pos_3button_rect[];
extern const int pos_4button_rect[];
extern const int pos_5button_rect[];

extern const int pos_1deck_rect[];
extern const int pos_2deck_rect[];
extern const int pos_3deck_rect[];
extern const int pos_4deck_rect[];
extern const int pos_slow_rect[];
extern const int pos_medium_rect[];
extern const int pos_fast_rect[];
extern const int pos_on_rect[];
extern const int pos_off_rect[];

extern const int dest_rules_rect[];
extern const int dest_options_rect[];
extern const int dest_about_rect[];
extern const int dest_white_rect[];

extern const int mask1_rect[];
extern const int mask2_rect[];

extern const char *scrolling_rules[];
extern const char *scrolling_about[];
extern const char *static_options[];

#endif // CONSTANTS_H
