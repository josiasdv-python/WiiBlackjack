#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <malloc.h>
#include <gccore.h>
#include <ogc/tpl.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <asndlib.h>
#include <mp3player.h>

#include "gxconsole.h"			// To display console text with graphics

#include "variables.h"
#include "constants.h"
#include "functions.h"

#include "textures_tpl.h"		// Generated texture files at compile
#include "textures.h"

#include "CardDeal_raw.h"		// Generated raw audio and mp3 headers at compile
#include "CoinChange_raw.h"
#include "Cheer_mp3.h"
#include "ChipReturn_mp3.h"
#include "CoinChange_mp3.h"
#include "SensationRag_mp3.h"
#include "Error_mp3.h"
#include "TwoSecSilence_mp3.h"

#define DEFAULT_FIFO_SIZE (256*1024)
#define DEFAULT_DATA_DIR "sd:/apps/wiiblackjack/data"
#define SCORE_FILENAME "highscore.txt"
#define MAIN_STYLE "\033[38;2;255;255;255;48;2;0;91;19m"
#define OPTIONS_STYLE "\033[38;2;255;255;255;48;2;64;64;64m"
#define BOLD_STYLE "\033[1m"

#endif // MAIN_H
