#ifndef VARIABLES_H
#define VARIABLES_H

#include <ogc/tpl.h>
#include <wiiuse/wpad.h>

// Framebuffer and GX pointers
extern void *xfb;
extern GXRModeObj *rmode;

// Empty texture object
extern GXTexObj texObj;
extern TPLFile spriteTPL;

// Wiimote infrared data variable
extern ir_t ir;

// Gxconsole set position variables
extern int content_row;
extern int content_col;

// External starting cash
extern int player_coins;
extern int high_score;

// External bet current
extern int bet_current;

// External animation speed
extern int animation_speed;

// External card count
extern int card_count_toggle;
extern int card_count_running;
extern int once_count_2nd_dealer_card;

// External default number of decks
extern int num_of_decks;
extern int top_card_of_deck;

// Create a struct called Card
typedef struct {
	const char *rank;
	const char *suit;
} Card;

// External the empty decks
extern Card deck_a[52];
extern Card deck_b[52];
extern Card deck_c[52];
extern Card deck_d[52];
extern Card deck[208];

// External empty player and dealer hands 
extern Card player_cards[5];
extern Card dealer_cards[5]; 
extern Card split_a_cards[5];
extern Card split_b_cards[5];

extern int num_of_player_cards;
extern int num_of_dealer_cards;
extern int num_of_split_a_cards;
extern int num_of_split_b_cards;

extern int dealer_score;
extern int player_score;
extern int split_a_score;
extern int split_b_score;

extern bool double_down_flag;
extern bool double_down_split_a;
extern bool double_down_split_b;
extern bool triple_down_flag;
extern bool triple_down_split_a;
extern bool triple_down_split_b;
extern bool split_flag;
extern bool rotate_flag;
extern bool seven_flag;
extern bool insurance_flag;

#endif // VARIABLES_H
