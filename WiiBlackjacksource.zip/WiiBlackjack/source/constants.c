#include "constants.h"

// Define images rectangles
const int card_rect[] = {0, 0, 60, 96};
const int middle_rect[] = {((640 - 200) / 2) - 30, (480 / 2), 60, 96};
const int basic_rect[] = {440, 0, 200, 480};
const int table_green_rect[] = {70, 180, 300, 160};

// Define player and dealer rectangles
const int dealer_rect_1[] = {middle_rect[0], card_rect[3] / 6, card_rect[2], card_rect[3]};
const int dealer_rect_2[] = {middle_rect[0] + 62, card_rect[3] / 6, card_rect[2], card_rect[3]};
const int dealer_rect_3[] = {middle_rect[0] - 62, card_rect[3] / 6, card_rect[2], card_rect[3]};
const int dealer_rect_4[] = {middle_rect[0] - 62 * 2, card_rect[3] / 6, card_rect[2], card_rect[3]};
const int dealer_rect_5[] = {middle_rect[0] - 62 * 3, card_rect[3] / 6, card_rect[2], card_rect[3]};
const int player_rect_1[] = {middle_rect[0] - 29 * 2, 202, card_rect[2], card_rect[3]};
const int player_rect_2[] = {middle_rect[0] - 29, 202 - card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_rect_3[] = {middle_rect[0], 202 - 2 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_rect_4[] = {middle_rect[0] + 29, 202 - 3 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_rect_5[] = {middle_rect[0] + 29 * 2, 202 - 4 * card_rect[3] / 5, card_rect[2], card_rect[3]};

// Define split rectangles
const int player_split_1[] = {180 - 29 * 3, 202, card_rect[2], card_rect[3]};
const int player_split_2[] = {180 - 29 * 2, 202 - card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_3[] = {180 - 29, 202 - 2 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_4[] = {180, 202 - 3 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_5[] = {180 + 29, 202 - 4 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_6[] = {200 - 29, 202, card_rect[2], card_rect[3]};
const int player_split_7[] = {200, 202 - card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_8[] = {200 + 29, 202 - 2 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_9[] = {200 + 29 * 2, 202 - 3 * card_rect[3] / 5, card_rect[2], card_rect[3]};
const int player_split_10[] = {200 + 29 * 3, 202 - 4 * card_rect[3] / 5, card_rect[2], card_rect[3]};

// Define button rectangles
const int stand_button_rect[] = 	{middle_rect[0] - 70 * 2, 420, card_rect[2], 22};
const int hit_button_rect[] = 		{middle_rect[0] - 70, 420, card_rect[2], 22};
const int double_button_rect[] = 	{middle_rect[0], 420, card_rect[2], 22};
const int triple_button_rect[] = 	{middle_rect[0] + 70, 420, card_rect[2], 22};
const int split_button_rect[] = 	{middle_rect[0] + 70 * 2, 420, card_rect[2], 22};
const int bet10_button_rect[] = 	{middle_rect[0] - 70 * 2, 420, card_rect[2], 22};
const int bet25_button_rect[] = 	{middle_rect[0] - 70, 420, card_rect[2], 22};
const int bet50_button_rect[] = 	{middle_rect[0], 420, card_rect[2], 22};
const int bet100_button_rect[] = 	{middle_rect[0] + 70, 420, card_rect[2], 22};
const int bet250_button_rect[] = 	{middle_rect[0] + 70 * 2, 420, card_rect[2], 22};
const int yes_button_rect[] = 		{middle_rect[0] - 70, 420, card_rect[2], 22};
const int no_button_rect[] = 		{middle_rect[0] + 70, 420, card_rect[2], 22};
const int new_button_rect[] = 		{middle_rect[0] - 70 * 2, 420, card_rect[2], 22};
const int rules_button_rect[] = 	{middle_rect[0] - 70, 420, card_rect[2], 22};
const int options_button_rect[] = 	{middle_rect[0], 420, card_rect[2], 22};
const int about_button_rect[] = 	{middle_rect[0] + 70, 420, card_rect[2], 22};
const int quit_button_rect[] = 		{middle_rect[0] + 70 * 2, 420, card_rect[2], 22};
const int confirm_button_rect[] = 	{middle_rect[0] - 70, 420, card_rect[2], 22};
const int default_button_rect[] = 	{middle_rect[0], 420, card_rect[2], 22};
const int cancel_button_rect[] = 	{middle_rect[0] + 70, 420, card_rect[2], 22};

// Define circle selection rectangles
const int deck1_circle[] = 	{middle_rect[0] + 6, 128, 17, 19};
const int deck2_circle[] = 	{middle_rect[0] + 54, 128, 17, 19};
const int deck3_circle[] = 	{middle_rect[0] + 102, 128, 17, 19};
const int deck4_circle[] = 	{middle_rect[0] + 150, 128, 17, 19};
const int slow_circle[] = 	{middle_rect[0] + 6, 180, 17, 19};
const int medium_circle[] = {middle_rect[0] + 70, 180, 17, 19};
const int fast_circle[] = 	{middle_rect[0] + 150, 180, 17, 19};
const int on_circle[] = 	{middle_rect[0] + 6, 232, 17, 19};
const int off_circle[] = 	{middle_rect[0] + 54, 232, 17, 19};

// Define the button position collision
const int pos_1button_rect[] = {30, 396, 90, 416};
const int pos_2button_rect[] = {100, 396, 160, 416};
const int pos_3button_rect[] = {170, 396, 230, 416};
const int pos_4button_rect[] = {240, 396, 300, 416};
const int pos_5button_rect[] = {310, 396, 370, 416};

// Define the circle selection collision
const int pos_1deck_rect[] = {176, 102, 192, 118};
const int pos_2deck_rect[] = {224, 102, 240, 118};
const int pos_3deck_rect[] = {272, 102, 288, 118};
const int pos_4deck_rect[] = {320, 102, 336, 118};
const int pos_slow_rect[] = {176, 154, 192, 170};
const int pos_medium_rect[] = {240, 154, 256, 170};
const int pos_fast_rect[] = {320, 154, 336, 170};
const int pos_on_rect[] = {176, 206, 192, 222};
const int pos_off_rect[] = {224, 206, 240, 222};

// Main menu destination rectangles
const int dest_rules_rect[] = {20, 20, 640 - basic_rect[2] - 40, 480 - 40};
const int dest_options_rect[] = {20, 20, 640 - basic_rect[2] - 40, 480 - 40};
const int dest_about_rect[] = {20, 20, 640 - basic_rect[2] - 40, 480 - 40};
const int dest_white_rect[] = {39, 39, 640 - basic_rect[2] - 78, 480 - 114};

// Main menu mask rectangles
const int mask1_rect[] = {20, 0, 640 - basic_rect[2] - 40, 20};
const int mask2_rect[] = {20, 480 - 20, 640 - basic_rect[2] - 40, 20};

// Define text
const char *scrolling_rules[] = {
							"House Rules that benefit the Player:"," ",
                            "Blackjack pays 3 to 2.",
                            "Unnatural Blackjack (after Split) pays 3 to 2.",
                            "Suited Blackjack pays 2 to 1."," ",
                            "Split allowed on any Pair.",
                            "Any 10 value card is considered a Pair."," ",
                            "Double Down on any card total.",
                            "Double or Triple Down allowed after Split."," ",
                            "Maximum Player or Dealer cards is 5.",
                            "5 Player cards dealt without bust (Charlie)...",
                            "wins unless Dealer has Blackjack."," ",
                            "Five-Card Charlie allowed after Split.",
                            "Five-Card Charlie pays 2 to 1."," ",
                            "777 wins outright and pays 3 to 1."," "," "," "," ",
							" "," "," "," "," "," "," "," ",
                            "House Rules that benefit the Dealer:"," ",
                            "Dealer hits on Soft 17.",
                            "$10 Min. Bet and $250 Max. Bet",
							"(Low Spread)", " ",
                            "Player Blackjack wins immediately unless...",
                            "Dealer also has one, then result is a Push."," ",
                            "No-Peek Table means the Dealer...",
                            "won't check for Blackjack till Player is done."," ",
                            "Split allowed only after the first deal.",
                            "Triple Down only on Hard 9, 10, or 11.",
                            "Double or Triple Down not allowed after Hit."," ",
                            "Insurance allowed only after the first deal.",
                            "Insurance pays 2 to 1 but costs half the Bet.",
                            "Surrender is not allowed.", NULL
};
const char *scrolling_about[] = {    
                            "Blackjack! made using:"," ",
                            "Python 3.13.2",
                            "Pygame 2.6.1"," ",
							"Ported to Wii in October, 2026"," ",
							"libogc 3.2.0",
							"devkitpro Updater 3.0.3",
							"GxConsole by \"barfoo34\""," ",
                            "Blackjack Font provided free by:",
                            "Typadelic Fonts Copyright 2002"," ",
                            "Card images by \"Sleepy\"",
                            "Basic Strategy images by \"Josias\"",
                            "(referencing https://wizardofodds.com)"," ",
                            "Sound by https://freesound.org"," ",
                            "\"Sensation Rag\" - 1908",
                            "Music Composed by Joseph F. Lamb",
                            "Arranged by Scott Joplin",
                            "MIDI Sequenced By Colin D. MacDonald",
                            "https://ragtimemusic.com", NULL
};
const char *static_options[] = {
							"						 Options"
							" "," "," "," "," ",
							"  Decks in Shoe		 1     2     3     4",
                            " "," "," ",
							"  Animation Speed		 Slow    Medium    Fast",
							" "," "," ",
                            "  True Card Count		 On    Off", NULL
};
