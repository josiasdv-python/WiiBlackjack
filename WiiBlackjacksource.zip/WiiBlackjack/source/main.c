#include "main.h"

//---------------------------------------------------------------------------------
// Main function
//---------------------------------------------------------------------------------

int main( int argc, char **argv ){

	// Initialize everything
	VIDEO_Init();
	WPAD_Init();
	ASND_Init();
	MP3Player_Init();
	
	// Setup video and GX
	rmode = VIDEO_GetPreferredMode(NULL);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	VIDEO_ClearFrameBuffer(rmode, xfb, COLOR_BLACK);
	
	void *fifoBuffer = NULL;
	fifoBuffer = memalign(32, DEFAULT_FIFO_SIZE);
	memset(fifoBuffer, 0, DEFAULT_FIFO_SIZE);
	GX_Init(fifoBuffer, DEFAULT_FIFO_SIZE);
	
	float yscale = GX_GetYScaleFactor(rmode->efbHeight, rmode->xfbHeight);
	u32 xfbHeight = GX_SetDispCopyYScale(yscale);
	GX_SetViewport(0, 0, rmode->fbWidth, rmode->efbHeight, 0, 1);
	GX_SetScissor(0, 0, rmode->fbWidth, rmode->efbHeight);
	GX_SetDispCopySrc(0, 0, rmode->fbWidth, rmode->efbHeight);
	GX_SetDispCopyDst(rmode->fbWidth, xfbHeight);
	GX_SetCopyFilter(rmode->aa, rmode->sample_pattern, GX_TRUE, rmode->vfilter);
	GX_SetFieldMode(rmode->field_rendering, ((rmode->viHeight==2*rmode->xfbHeight)?GX_ENABLE:GX_DISABLE));
	GX_SetPixelFmt(GX_PF_RGB8_Z24, GX_ZC_LINEAR);
	GX_SetZMode(GX_TRUE, GX_LEQUAL, GX_FALSE);
	GX_SetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);

	// Matrix for texture perspective
	Mtx44 sprite_perspective;
	guOrtho(sprite_perspective, 0, rmode->efbHeight, 0, rmode->fbWidth, 0, 1);
	GX_LoadProjectionMtx(sprite_perspective, GX_ORTHOGRAPHIC);
	GX_SetCurrentMtx(GX_IDENTITY);
	
	VIDEO_Configure(rmode);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(false);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();
	
	// Setup for wii infrared
	WPAD_SetVRes(0, rmode->fbWidth, rmode->efbHeight);
	WPAD_SetDataFormat(WPAD_CHAN_0, WPAD_FMT_BTNS_ACC_IR);
	
	// Load textures
	TPL_OpenTPLFromMemory(&spriteTPL, (void *)textures_tpl, textures_tpl_size);

	// Set what color background will be cleared to
	GXColor background = {0, 89, 16, 0xff};
	GX_SetCopyClear(background, GX_MAX_Z24);
	
	// Resolve the directory where the app .dol resides
    char app_path[256];
	char data_path[256 + 10];
    char score_path[256 + 10 + sizeof(SCORE_FILENAME) + 1];
    
	bool dir_resolved = false;
    // Ensure argv[0] exists and includes a drive prefix like "sd:" or "usb:"
    if (argc > 0 && argv != NULL && argv[0] != NULL && strchr(argv[0], ':') != NULL) {
		snprintf(app_path, sizeof(app_path), "%s", argv[0]);

        // Strip the executable filename (e.g. "/boot.dol") to leave just the folder path
        char *last_slash = strrchr(app_path, '/');
        if (last_slash != NULL) {
            *last_slash = '\0';
			
			// Append the data directory
			snprintf(data_path, sizeof(data_path), "%s/data", app_path);
            dir_resolved = true;
        }
    }

    // Fallback when launched remotely (e.g. via Wiiload or Dolphin without a mounted path)
    if (!dir_resolved) snprintf(data_path, sizeof(data_path), "%s", DEFAULT_DATA_DIR);

    // Build the full path to highscore.txt
    snprintf(score_path, sizeof(score_path), "%s/%s", data_path, SCORE_FILENAME);

	// Mount all available FAT storage devices
	bool sd_ready = fatInitDefault();

    if (sd_ready) {

        // Verify the app's data folder exists, creating it if necessary
        if (!dir_exists(data_path)) dir_create(data_path);

        // Load existing high score file, or create a fresh one initialized to 1000
		FILE *check = fopen(score_path, "r");
		if (!check) {		
			save_highscore(score_path, 1000);
		}
		else {
			fclose(check);
			high_score = load_highscore(score_path);
		}      
    }

	// Create the desks
	new_deck(deck_a);
	new_deck(deck_b);
	new_deck(deck_c);
	new_deck(deck_d);
	
	// Needed for rules and about to return without woosh
	int once_woosh = 1;
	
//---------------------------------------------------------------------------------
// Main menu section
//---------------------------------------------------------------------------------

	Main_menu_section:
	
	// Assess the high score
	if (high_score < player_coins) {
        if (sd_ready) save_highscore(score_path, player_coins);
		high_score = player_coins;
	}
	
	// Create the console for stdout
    GxConsole *con_stdout = gx_console_new(56, 7, &font_normalbold_8x13);
	gx_console_set_input(con_stdout, 1);
	
	// The console understands VT terminal escape codes
	content_row = 1;
	content_col = 1;
	set_pos(content_row, content_col);

	// Set background and text color of the console
	printf(MAIN_STYLE);
	while (content_row <= 7) {
		printf("                                                        ");
		content_row++;
		set_pos(content_row, content_col);
	}

	if (once_woosh == 1) {
		
		// Draw the main console at position
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		draw_table(table_green_rect);
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
		
		// Make sure the framebuffer is ready to woosh with mirror effect
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		draw_table(table_green_rect);
		
		GX_DrawDone();		
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();

		ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
						(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
		
		// Woosh the basic strategy
		woosh_main_menu();
	}
	
	MP3Player_Volume(200);
	if (!(MP3Player_IsPlaying())) MP3Player_PlayBuffer(SensationRag_mp3, SensationRag_mp3_size, NULL);
	
	set_pos(1, 1);
	printf("                                                        ");
	set_pos(7, 1);
	printf("                                                        ");
	set_pos(1, 20);	
	printf("High Score $%d", high_score);

	// Choose from menu items
	while (true) {
		
		WPAD_ScanPads();
        u32 pressed = WPAD_ButtonsHeld(0);
		u32 released = WPAD_ButtonsUp(0);
		WPAD_IR(0, &ir);
		
		if (pressed & WPAD_BUTTON_HOME) clean_up();
		
		// Draw the main console at position
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_main_menu();
		
		if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
			if (ir.x >= pos_1button_rect[0] && ir.x <= pos_1button_rect[2]) {
				if (pressed & WPAD_BUTTON_A) {
					TPL_GetTexture(&spriteTPL,NewGameGrey_Button,&texObj);
					draw_button_mask(new_button_rect);
				}
				else {
					TPL_GetTexture(&spriteTPL,NewGameLight_Button,&texObj);
					draw_button_mask(new_button_rect);	
				}
				if (released & WPAD_BUTTON_A) break;
			}
			if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
				if (pressed & WPAD_BUTTON_A) {
					TPL_GetTexture(&spriteTPL,TableRulesGrey_Button,&texObj);
					draw_button_mask(rules_button_rect);
				}
				else {
					TPL_GetTexture(&spriteTPL,TableRulesLight_Button,&texObj);
					draw_button_mask(rules_button_rect);	
				}
				if (released & WPAD_BUTTON_A) {
					// Draw the player pointer
					draw_player_pointer();
					
					GX_DrawDone();
					GX_CopyDisp(xfb, GX_FALSE);
					VIDEO_WaitVSync();
					
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
					woosh_black_box(dest_rules_rect);
						
					// Create the console for stdout
					GxConsole *con_stdout = gx_console_new(47, 63, &font_normalbold_8x13);
					gx_console_set_input(con_stdout, 1);
					
					set_pos(1, 1);
					printf("\033[2J");	// Clear the entire console
					printf(BOLD_STYLE);
					
					// Loop and print each string
					int count = count_array(scrolling_rules);
					
					for (int i = 0; i < count; i++) {
						int len = strlen(scrolling_rules[i]);
        
						// Calculate padding needed on the left side
						int left_padding = (47 - len) / 2;
						
						// %*s prints an empty string padded out to left_padding spaces
						printf("%*s%s\n", left_padding, "", scrolling_rules[i]);	
					}
				
					int temp_vertical = 460;
					
					while (true) {
						
						WPAD_ScanPads();
						u32 released = WPAD_ButtonsUp(0);
						
						for (int i = 0; i < 3; i++) {
							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							TPL_GetTexture(&spriteTPL,TextureBlack,&texObj);
							draw_button_mask(dest_rules_rect);				
							
							// Draw the main console at position
							fflush(stdout);
							gx_console_draw(con_stdout, 36, temp_vertical);

							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							draw_strategy(basic_rect);
							TPL_GetTexture(&spriteTPL,TextureGreen,&texObj);
							draw_button_mask(mask1_rect);
							draw_button_mask(mask2_rect);	
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
						}
						
						temp_vertical--;
						if (temp_vertical == -640) temp_vertical = 460;
						if (released & WPAD_BUTTON_A) {
							once_woosh = 0;
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							goto Main_menu_section;
						}
					}
				}
			}
			if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
				if (pressed & WPAD_BUTTON_A) {
					TPL_GetTexture(&spriteTPL,OptionsGrey_Button,&texObj);
					draw_button_mask(options_button_rect);
				}
				else {
					TPL_GetTexture(&spriteTPL,OptionsLight_Button,&texObj);
					draw_button_mask(options_button_rect);	
				}
				if (released & WPAD_BUTTON_A) {
					
					// Draw the player pointer
					draw_player_pointer();
					
					GX_DrawDone();
					GX_CopyDisp(xfb, GX_FALSE);
					VIDEO_WaitVSync();
					
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
					woosh_black_box(dest_options_rect);
					
					// Create the console for stdout
					GxConsole *con_stdout = gx_console_new(45, 28, &font_normalbold_8x13);
					gx_console_set_input(con_stdout, 1);
					
					content_row = 1;
					content_col = 1;
					set_pos(content_row, content_col);
					
					printf("\033[2J");	// Clear the entire console
					printf(OPTIONS_STYLE);
					while (content_row <= 28) {
						printf("                                             ");
						content_row++;
						set_pos(content_row, content_col);
					}
					
					// Loop and print each string
					set_pos(3, 1);
					int count = count_array(static_options);
					for (int i = 0; i < count; i++) {
						printf("%s\n", static_options[i]);
					}
					
					// Create a list that has the current state of all options
					int options_list[] = {num_of_decks, animation_speed, card_count_toggle};
					
					while (true) {
						
						WPAD_ScanPads();
						u32 pressed = WPAD_ButtonsHeld(0);
						u32 released = WPAD_ButtonsUp(0);
						WPAD_IR(0, &ir);

						// Function to setup the vertex descriptor for sprites
						setup_vertex();
						TPL_GetTexture(&spriteTPL,TextureBlack,&texObj);
						draw_button_mask(dest_options_rect);
						TPL_GetTexture(&spriteTPL,TextureWhite,&texObj);
						draw_button_mask(dest_white_rect);			
						
						// Draw the main console at position
						fflush(stdout);
						gx_console_draw(con_stdout, 40, 40);

						// Function to setup the vertex descriptor for sprites
						setup_vertex();
						fill_screen_options();
						
						// Mouse hover code for buttons
						if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
							if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
								if (pressed & WPAD_BUTTON_A) {
									TPL_GetTexture(&spriteTPL,ConfirmGrey_Button,&texObj);
									draw_button_mask(confirm_button_rect);
								}
								else {
									TPL_GetTexture(&spriteTPL,ConfirmLight_Button,&texObj);
									draw_button_mask(confirm_button_rect);	
								}
								if (released & WPAD_BUTTON_A) {
									
									// Draw the player pointer
									draw_player_pointer();
									
									GX_DrawDone();
									GX_CopyDisp(xfb, GX_TRUE);
									VIDEO_WaitVSync();
									
									num_of_decks = options_list[0];
									animation_speed = options_list[1];
									card_count_toggle = options_list[2];
									
									once_woosh = 1;
									goto Main_menu_section;
								}
							}
							if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
								if (pressed & WPAD_BUTTON_A) {
									TPL_GetTexture(&spriteTPL,DefaultGrey_Button,&texObj);
									draw_button_mask(default_button_rect);
								}
								else {
									TPL_GetTexture(&spriteTPL,DefaultLight_Button,&texObj);
									draw_button_mask(default_button_rect);	
								}
								if (released & WPAD_BUTTON_A) {
									
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									
									options_list[0] = 2;
									options_list[1] = 15;
									options_list[2] = 0;
								}
							}
							if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
								if (pressed & WPAD_BUTTON_A) {
									TPL_GetTexture(&spriteTPL,CancelGrey_Button,&texObj);
									draw_button_mask(cancel_button_rect);
								}
								else {
									TPL_GetTexture(&spriteTPL,CancelLight_Button,&texObj);
									draw_button_mask(cancel_button_rect);	
								}
								if (released & WPAD_BUTTON_A) {
									
									// Draw the player pointer
									draw_player_pointer();
									
									GX_DrawDone();
									GX_CopyDisp(xfb, GX_TRUE);
									VIDEO_WaitVSync();
									
									once_woosh = 1;
									goto Main_menu_section;
								}
							}
						}
						
						// Mouse hover code for selection rectangles
						if (ir.y >= pos_1deck_rect[1] && ir.y <= pos_1deck_rect[3]) {
							if (ir.x >= pos_1deck_rect[0] && ir.x <= pos_1deck_rect[2]) {
								if (options_list[0] != 1) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(deck1_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[0] = 1;
								}
							}
							if (ir.x >= pos_2deck_rect[0] && ir.x <= pos_2deck_rect[2]) {
								if (options_list[0] != 2) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(deck2_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[0] = 2;
								}
							}
							if (ir.x >= pos_3deck_rect[0] && ir.x <= pos_3deck_rect[2]) {
								if (options_list[0] != 3) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(deck3_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[0] = 3;
								}
							}
							if (ir.x >= pos_4deck_rect[0] && ir.x <= pos_4deck_rect[2]) {
								if (options_list[0] != 4) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(deck4_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[0] = 4;
								}
							}
						}
						if (ir.y >= pos_slow_rect[1] && ir.y <= pos_slow_rect[3]) {
							if (ir.x >= pos_slow_rect[0] && ir.x <= pos_slow_rect[2]) {
								if (options_list[1] != 20) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(slow_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[1] = 20;
								}
							}
							if (ir.x >= pos_medium_rect[0] && ir.x <= pos_medium_rect[2]) {
								if (options_list[1] != 15) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(medium_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[1] = 15;
								}
							}
							if (ir.x >= pos_fast_rect[0] && ir.x <= pos_fast_rect[2]) {
								if (options_list[1] != 10) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(fast_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[1] = 10;
								}
							}
						}
						if (ir.y >= pos_on_rect[1] && ir.y <= pos_on_rect[3]) {
							if (ir.x >= pos_on_rect[0] && ir.x <= pos_on_rect[2]) {
								if (options_list[2] != 1) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(on_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[2] = 1;
								}
							}
							if (ir.x >= pos_off_rect[0] && ir.x <= pos_off_rect[2]) {
								if (options_list[2] != 0) {
									TPL_GetTexture(&spriteTPL,SelectionWhite,&texObj);
									draw_button_mask(off_circle);
								}
								if (released & WPAD_BUTTON_A) {
									ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
													(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
									options_list[2] = 0;
								}
							}
						}
						
						// Check options and fill cirlces with current options
						if (options_list[0] == 1) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(deck1_circle);
						}
						if (options_list[0] == 2) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(deck2_circle);
						}
						if (options_list[0] == 3) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(deck3_circle);
						}
						if (options_list[0] == 4) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(deck4_circle);
						}
						if (options_list[1] == 20) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(slow_circle);
						}
						if (options_list[1] == 15) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(medium_circle);
						}
						if (options_list[1] == 10) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(fast_circle);
						}
						if (options_list[2] == 1) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(on_circle);
						}
						if (options_list[2] == 0) {
							TPL_GetTexture(&spriteTPL,SelectionBlue,&texObj);
							draw_button_mask(off_circle);
						}
						
						// Draw the player pointer
						draw_player_pointer();
						
						GX_DrawDone();
						GX_CopyDisp(xfb, GX_TRUE);
						VIDEO_WaitVSync();

						if (released & WPAD_BUTTON_HOME) goto Main_menu_section;
					}	
				}
			}
			if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
				if (pressed & WPAD_BUTTON_A) {
					TPL_GetTexture(&spriteTPL,AboutGrey_Button,&texObj);
					draw_button_mask(about_button_rect);
				}
				else {
					TPL_GetTexture(&spriteTPL,AboutLight_Button,&texObj);
					draw_button_mask(about_button_rect);	
				}
				if (released & WPAD_BUTTON_A) {				
					
					// Draw the player pointer
					draw_player_pointer();
					
					GX_DrawDone();
					GX_CopyDisp(xfb, GX_FALSE);
					VIDEO_WaitVSync();
					
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
					woosh_black_box(dest_about_rect);
						
					// Create the console for stdout
					GxConsole *con_stdout = gx_console_new(47, 33, &font_normalbold_8x13);
					gx_console_set_input(con_stdout, 1);
					
					set_pos(1, 1);
					printf("\033[2J");
					printf(BOLD_STYLE);
					
					// Loop and print each string
					int count = count_array(scrolling_about);
					
					for (int i = 0; i < count; i++) {
						int len = strlen(scrolling_about[i]);
        
						// Calculate padding needed on the left side
						int left_padding = (47 - len) / 2;
						
						// %*s prints an empty string padded out to left_padding spaces
						printf("%*s%s\n", left_padding, "", scrolling_about[i]);	
					}
					
					int temp_vertical = 460;
					
					while (true) {
						
						WPAD_ScanPads();
						u32 released = WPAD_ButtonsUp(0);
						
						for (int i = 0; i < 3; i++) {
							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							TPL_GetTexture(&spriteTPL,TextureBlack,&texObj);
							draw_button_mask(dest_about_rect);				
							
							// Draw the main console at position
							fflush(stdout);
							gx_console_draw(con_stdout, 36, temp_vertical);

							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							draw_strategy(basic_rect);
							TPL_GetTexture(&spriteTPL,TextureGreen,&texObj);
							draw_button_mask(mask1_rect);
							draw_button_mask(mask2_rect);	
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
						}
						
						temp_vertical--;
						if (temp_vertical == -320) temp_vertical = 460;
						if (released & WPAD_BUTTON_A) {
							once_woosh = 0;
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							goto Main_menu_section;
						}
					}
				}	
			}
			if (ir.x >= pos_5button_rect[0] && ir.x <= pos_5button_rect[2]) {
				if (pressed & WPAD_BUTTON_A) {
					TPL_GetTexture(&spriteTPL,QuitGrey_Button,&texObj);
					draw_button_mask(quit_button_rect);
				}
				else {
					TPL_GetTexture(&spriteTPL,QuitLight_Button,&texObj);
					draw_button_mask(quit_button_rect);	
				}
				if (released & WPAD_BUTTON_A) clean_up();
			}
		}

		// Draw the player pointer
		draw_player_pointer();

		// All Drawing done from console and sprites
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
	}
	
	// Draw the player pointer
	draw_player_pointer();
	
	GX_DrawDone();
	GX_CopyDisp(xfb, GX_TRUE);
	VIDEO_WaitVSync();
		
//---------------------------------------------------------------------------------
// Blackjack section
//---------------------------------------------------------------------------------
	
	if (MP3Player_IsPlaying()) {
		for (int i = 200; i < 1; i--) {
			MP3Player_Volume(i);
			VIDEO_WaitVSync();	
		}
		MP3Player_Stop();
	}
	
	// Set or reset player coins to 1000
    player_coins = 1000;
    
	// Reset the card count
    card_count_running = 0;
	
	// Reset deck
	fresh_deck();
	
	// Game loop
    while (player_coins > 0) {
        
        // Reset variables
		num_of_player_cards = 0;
		num_of_dealer_cards = 0;
		num_of_split_a_cards = 0;
		num_of_split_b_cards = 0;
        dealer_score = 0;
        player_score = 0;
        split_a_score = 0;
        split_b_score = 0;

        double_down_flag = false;
        double_down_split_a = false;
        double_down_split_b = false;
        triple_down_flag = false;
        triple_down_split_a = false;
        triple_down_split_b = false;
        split_flag = false;
        seven_flag = false;
        insurance_flag = false;
	
		// New deck if running low
		if (top_card_of_deck < 15) fresh_deck();
		
//---------------------------------------------------------------------------------
// Player bets amount
//---------------------------------------------------------------------------------
		
		// Player bets amount
		while (true) {
			
			set_pos(1, 1);
			printf("                                                        ");
			set_pos(1, 17);	
			printf("How much will you bet?");
			set_pos(7, 1);
			printf("                                                        ");
			set_pos(7, 1);
			printf("$%d ", player_coins);
			
			// Draw card counting if activated
			if (card_count_toggle) {
				set_pos(7, 53);
				if (card_count_running / ((top_card_of_deck / 52) + (top_card_of_deck % 52 > 0)) < 0) \
					printf("%d ", card_count_running / ((top_card_of_deck / 52) + (top_card_of_deck % 52 > 0)));
				else printf("+%d ", card_count_running / ((top_card_of_deck / 52) + (top_card_of_deck % 52 > 0)));
			}
			
			WPAD_ScanPads();
			u32 pressed = WPAD_ButtonsHeld(0);
			u32 released = WPAD_ButtonsUp(0);
			WPAD_IR(0, &ir);
			
			if (pressed & WPAD_BUTTON_HOME) goto Main_menu_section;
			
			// Draw the main console at position
			fflush(stdout);
			gx_console_draw(con_stdout, 4, 380);

			// Function to setup the vertex descriptor for sprites
			setup_vertex();
			fill_screen_bet();
			
			if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
				if (ir.x >= pos_1button_rect[0] && ir.x <= pos_1button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,Bet10Grey_Button,&texObj);
						draw_button_mask(bet10_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,Bet10Light_Button,&texObj);
						draw_button_mask(bet10_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						bet_current = 10;
						player_coins -= bet_current;
						break;
					}				
				}
				if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,Bet25Grey_Button,&texObj);
						draw_button_mask(bet25_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,Bet25Light_Button,&texObj);
						draw_button_mask(bet25_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						bet_current = 25;
						player_coins -= bet_current;
						break;
					}
				}
				if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,Bet50Grey_Button,&texObj);
						draw_button_mask(bet50_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,Bet50Light_Button,&texObj);
						draw_button_mask(bet50_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						bet_current = 50;
						player_coins -= bet_current;
						break;
					}
				}
				if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,Bet100Grey_Button,&texObj);
						draw_button_mask(bet100_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,Bet100Light_Button,&texObj);
						draw_button_mask(bet100_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						bet_current = 100;
						player_coins -= bet_current;
						break;
					}
				}
				if (ir.x >= pos_5button_rect[0] && ir.x <= pos_5button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,Bet250Grey_Button,&texObj);
						draw_button_mask(bet250_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,Bet250Light_Button,&texObj);
						draw_button_mask(bet250_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						bet_current = 250;
						player_coins -= bet_current;
						break;
					}
				}
			}

			// Draw the player pointer
			draw_player_pointer();

			// All Drawing done from console and sprites
			GX_DrawDone();
			GX_CopyDisp(xfb, GX_TRUE);
			VIDEO_WaitVSync();
		}
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();

		// Deal 2 cards to the player	
		player_cards[num_of_player_cards] = deck[top_card_of_deck];
		--top_card_of_deck;
		++num_of_player_cards;
		
		player_cards[num_of_player_cards] = deck[top_card_of_deck];
		--top_card_of_deck;
		++num_of_player_cards;
		
		// Deal 2 cards to the dealer	
		dealer_cards[num_of_dealer_cards] = deck[top_card_of_deck];
		--top_card_of_deck;
		++num_of_dealer_cards;
		
		dealer_cards[num_of_dealer_cards] = deck[top_card_of_deck];
		--top_card_of_deck;
		++num_of_dealer_cards;
		
		set_pos(1, 1);
		printf("                                                        ");
		
		// Make sure the framebuffer is ready to woosh with mirror effect
		for (int i = 0; i < 2; i++) {
			// Draw the main console at position
			fflush(stdout);
			gx_console_draw(con_stdout, 4, 380);

			// Function to setup the vertex descriptor for sprites
			setup_vertex();
			fill_screen_buttons();
			
			// Draw the player pointer
			draw_player_pointer();
			
			GX_DrawDone();
			GX_CopyDisp(xfb, GX_FALSE);
			VIDEO_WaitVSync();
		}
		
		ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
						(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);

        // Woosh the first player card
		woosh(player_rect_1);
		
		WPAD_ScanPads();
		WPAD_IR(0, &ir);
		
		// Draw the main console at position
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();		
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
		
		// Make sure the framebuffer is ready to woosh with mirror effect
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
		
		ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
						(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
		
		// Woosh the first dealer card
		woosh(dealer_rect_1);
		
		WPAD_ScanPads();
		WPAD_IR(0, &ir);
		
		// Draw the main console at position
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		draw_card(dealer_cards[0], dealer_rect_1);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
		
		// Make sure the framebuffer is ready to woosh with mirror effect
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		draw_card(dealer_cards[0], dealer_rect_1);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
		
		ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
						(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
		
		// Woosh the second player card
		woosh(player_rect_2);
		
		WPAD_ScanPads();
		WPAD_IR(0, &ir);
		
		// Draw the main console at position
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		draw_card(dealer_cards[0], dealer_rect_1);
		draw_card(player_cards[1], player_rect_2);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
		
		// Make sure the framebuffer is ready to woosh with mirror effect
		fflush(stdout);
		gx_console_draw(con_stdout, 4, 380);

		// Function to setup the vertex descriptor for sprites
		setup_vertex();
		fill_screen_buttons();
		draw_card(player_cards[0], player_rect_1);
		draw_card(dealer_cards[0], dealer_rect_1);
		draw_card(player_cards[1], player_rect_2);
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
		
		ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
						(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
						
		// Woosh the second dealer card
		woosh(dealer_rect_2);
		
		// Calculate counting cards
		for (int i = 0; i < num_of_player_cards; i++) {
			card_count_running += count_value(player_cards[i]);
		}
		card_count_running += count_value(dealer_cards[0]);		// But not the 2nd dealer card
		
//---------------------------------------------------------------------------------
// Insurance
//---------------------------------------------------------------------------------
			
		// Insurance code
		if (strcmp(dealer_cards[0].rank, "Ace") == 0) {
			while (!insurance_flag) {      
				
				// Calculate player score based on card value only to see if player blackjack
				player_score = 0;
				for (int i = 0; i < num_of_player_cards; i++) {
					player_score += card_value(player_cards[i]);
				}
				
				// Check if player has blackjack
				if (player_score == 21 && num_of_player_cards == 2) break;
			
				WPAD_ScanPads();
				u32 pressed = WPAD_ButtonsHeld(0);
				u32 released = WPAD_ButtonsUp(0);
				WPAD_IR(0, &ir);

				if (pressed & WPAD_BUTTON_HOME) goto Main_menu_section;
				
				set_pos(1, 1);
				printf("                                                        ");
				set_pos(1, 6);	
				printf("Insurance - Will the Dealer have a Blackjack?");
				
				// Draw the main console at position
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_insurance();
				
				draw_card(player_cards[0], player_rect_1);
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(player_cards[1], player_rect_2);
				
				// Dealer's second card is not shown
				draw_card_back(dealer_rect_2);
				
				if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
					if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
						if (pressed & WPAD_BUTTON_A) {
							TPL_GetTexture(&spriteTPL,YesGrey_Button,&texObj);
							draw_button_mask(yes_button_rect);
						}
						else {
							TPL_GetTexture(&spriteTPL,YesLight_Button,&texObj);
							draw_button_mask(yes_button_rect);	
						}
						if (released & WPAD_BUTTON_A) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							player_coins -= bet_current / 2;
							
							// Drawing
							set_pos(1, 1);
							printf("                                                        ");
							set_pos(1, 20);	
							printf("Insurance taken.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								// Draw the player pointer
								draw_player_pointer();
							
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							insurance_flag = true;
							break;
						}
					}
					if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
						if (pressed & WPAD_BUTTON_A) {
							TPL_GetTexture(&spriteTPL,NoGrey_Button,&texObj);
							draw_button_mask(no_button_rect);
						}
						else {
							TPL_GetTexture(&spriteTPL,NoLight_Button,&texObj);
							draw_button_mask(no_button_rect);	
						}
						if (released & WPAD_BUTTON_A) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							// Drawing
							set_pos(1, 1);
							printf("                                                        ");
							set_pos(1, 19);	
							printf("Insurance declined.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							break;
						}
					}
				}
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
		}
		
//---------------------------------------------------------------------------------
// Player gets to hit, stand, double, triple, or split
//---------------------------------------------------------------------------------
		
		// Player gets to hit, stand, double, triple, or split
		while (true) {
			
			set_pos(1, 1);
			printf("                                                        ");
			
			WPAD_ScanPads();
			u32 pressed = WPAD_ButtonsHeld(0);
			u32 released = WPAD_ButtonsUp(0);
			WPAD_IR(0, &ir);
			
			if (pressed & WPAD_BUTTON_HOME) goto Main_menu_section;
			
			// Calculate player score based on card value
			player_score = 0;
			for (int i = 0; i < num_of_player_cards; i++) {
				player_score += card_value(player_cards[i]);
			}
			
			// Check for ace cards in player hand
			int ace_cards = 0;
			for (int i = 0; i < num_of_player_cards; i++) {
				if (strcmp(player_cards[i].rank, "Ace") == 0) ace_cards += 1;
			}
			while (ace_cards > 0 && player_score > 21) {
				player_score -= 10;
				ace_cards -= 1;
			}
			
			// Draw the main console at position
			fflush(stdout);
			gx_console_draw(con_stdout, 4, 380);

			// Function to setup the vertex descriptor for sprites
			setup_vertex();
			fill_screen_buttons();
			draw_card(player_cards[0], player_rect_1);
			draw_card(dealer_cards[0], dealer_rect_1);
			draw_card(player_cards[1], player_rect_2);
			
			// Dealer's second card is not shown
			draw_card_back(dealer_rect_2);
            
			if (num_of_player_cards >= 3) {
                if ((double_down_flag) || (triple_down_flag)) {
                    rotate_flag = true;
					draw_card(player_cards[2], player_rect_3);
					rotate_flag = false;
				}
                else {draw_card(player_cards[2], player_rect_3);}
			}
            if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
            if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);

			// Check if player has blackjack
            if (player_score == 21 && num_of_player_cards == 2) break;
			
			// Check if player bust, double down, or triple down
            if (player_score > 21) break;
            if ((double_down_flag) || (triple_down_flag)) break;
			
			// Check for 777
            if (num_of_player_cards == 3) {
                if ((strcmp(player_cards[0].rank, "7") == 0) && \
                    (strcmp(player_cards[1].rank, "7") == 0) && \
                    (strcmp(player_cards[2].rank, "7") == 0)) {
					seven_flag = true;
                    break;
				}   
			}
			
			// Check for five card charlie
            if (num_of_player_cards == 5) break;
			
			if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
				if (ir.x >= pos_1button_rect[0] && ir.x <= pos_1button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,StandGrey_Button,&texObj);
						draw_button_mask(stand_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,StandLight_Button,&texObj);
						draw_button_mask(stand_button_rect);	
					}
					if (released & WPAD_BUTTON_A) break;			
				}
				if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,HitGrey_Button,&texObj);
						draw_button_mask(hit_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,HitLight_Button,&texObj);
						draw_button_mask(hit_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						
						// Draw the player pointer
						draw_player_pointer();
							
						GX_DrawDone();
						GX_CopyDisp(xfb, GX_FALSE);
						VIDEO_WaitVSync();
						
						// Deal 1 card to the player
						player_cards[num_of_player_cards] = deck[top_card_of_deck];
						--top_card_of_deck;
						++num_of_player_cards;
						card_count_running += count_value(player_cards[(num_of_player_cards - 1)]);
						
                        ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
										(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
                        
						// Woosh the third, fourth, or fifth player card					
						if (num_of_player_cards == 3) woosh(player_rect_3);
						if (num_of_player_cards == 4) woosh(player_rect_4);
						if (num_of_player_cards == 5) woosh(player_rect_5);
					}
				}
				if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,DoubleGrey_Button,&texObj);
						draw_button_mask(double_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,DoubleLight_Button,&texObj);
						draw_button_mask(double_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						if (num_of_player_cards >= 3) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							set_pos(1, 14);	
							printf("Can't Double Down after Hit.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								if (num_of_player_cards >= 3) draw_card(player_cards[2], player_rect_3);
								if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							released = 0;
						}
                        else {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_FALSE);
							VIDEO_WaitVSync();
							
							double_down_flag = true;
                            player_coins -= bet_current;
							
							// Deal 1 card to the player
							player_cards[num_of_player_cards] = deck[top_card_of_deck];
							--top_card_of_deck;
							++num_of_player_cards;
							card_count_running += count_value(player_cards[(num_of_player_cards - 1)]);
                            
							ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
											(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
											
							// Woosh the third player card
							woosh(player_rect_3);
						}
					}
				}
				if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,TripleGrey_Button,&texObj);
						draw_button_mask(triple_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,TripleLight_Button,&texObj);
						draw_button_mask(triple_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						if (num_of_player_cards >= 3) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							set_pos(1, 14);	
							printf("Can't Triple Down after Hit.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								if (num_of_player_cards >= 3) draw_card(player_cards[2], player_rect_3);
								if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							released = 0;
						}
						else if (player_score < 9 || player_score > 11) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							set_pos(1, 9);	
							printf("Can only Triple Down on Hard 9, 10, 11.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								if (num_of_player_cards >= 3) draw_card(player_cards[2], player_rect_3);
								if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
								
								// Draw the player pointer
								draw_player_pointer();
							
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							released = 0;
						}
                        else {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_FALSE);
							VIDEO_WaitVSync();
							
							triple_down_flag = true;
                            player_coins -= bet_current;
							
							// Deal 1 card to the player
							player_cards[num_of_player_cards] = deck[top_card_of_deck];
							--top_card_of_deck;
							++num_of_player_cards;
							card_count_running += count_value(player_cards[(num_of_player_cards - 1)]);
						
							ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
											(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
											
							// Woosh the third player card
							woosh(player_rect_3);
						}
					}
				}
				if (ir.x >= pos_5button_rect[0] && ir.x <= pos_5button_rect[2]) {
					if (pressed & WPAD_BUTTON_A) {
						TPL_GetTexture(&spriteTPL,SplitGrey_Button,&texObj);
						draw_button_mask(split_button_rect);
					}
					else {
						TPL_GetTexture(&spriteTPL,SplitLight_Button,&texObj);
						draw_button_mask(split_button_rect);	
					}
					if (released & WPAD_BUTTON_A) {
						if (num_of_player_cards >= 3) {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							set_pos(1, 17);	
							printf("Can't Split after Hit.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								if (num_of_player_cards >= 3) draw_card(player_cards[2], player_rect_3);
								if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
						}
						else if (card_value(player_cards[0]) != card_value(player_cards[1])) {						
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							set_pos(1, 10);	
							printf("Can't Split if you don't have a Pair.");
							
							// Play mp3 file
							MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
							while (MP3Player_IsPlaying()) {
								
								WPAD_ScanPads();
								WPAD_IR(0, &ir);
								
								// Draw the main console at position
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(player_cards[0], player_rect_1);
								draw_card(dealer_cards[0], dealer_rect_1);
								draw_card(player_cards[1], player_rect_2);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								if (num_of_player_cards >= 3) draw_card(player_cards[2], player_rect_3);
								if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
						}
//---------------------------------------------------------------------------------
// Split
//---------------------------------------------------------------------------------					
						else {
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
							
							// Split code	
							split_flag = true;
							player_coins -= bet_current;
							
							num_of_player_cards = 0;
							split_a_cards[0] = player_cards[0];
							++num_of_split_a_cards;
							split_b_cards[0] = player_cards[1];
							++num_of_split_b_cards;
							
							// Deal 1 card to the split_a player
							split_a_cards[num_of_split_a_cards] = deck[top_card_of_deck];
							--top_card_of_deck;
							++num_of_split_a_cards;
							card_count_running += count_value(split_a_cards[(num_of_split_a_cards - 1)]);

							// Make sure the framebuffer is ready to woosh with mirror effect
							fflush(stdout);
							gx_console_draw(con_stdout, 4, 380);

							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							fill_screen_buttons();
							draw_card(dealer_cards[0], dealer_rect_1);
							
							// Dealer's second card is not shown
							draw_card_back(dealer_rect_2);
							
							draw_card(split_a_cards[0], player_split_6);
							draw_card(split_b_cards[0], player_split_1);
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_FALSE);
							VIDEO_WaitVSync();
					
							ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
											(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);

							woosh(player_split_7);

//---------------------------------------------------------------------------------
// Split a gets to hit, stand, double, triple, or split
//---------------------------------------------------------------------------------
				
							// Split a gets to hit, stand, or double down
							while (true) {
								
								set_pos(1, 1);
								printf("                                                        ");
								
								WPAD_ScanPads();
								u32 pressed = WPAD_ButtonsHeld(0);
								u32 released = WPAD_ButtonsUp(0);
								WPAD_IR(0, &ir);
								
								if (pressed & WPAD_BUTTON_HOME) goto Main_menu_section;
								
								// Calculate player_a score based on card value
								split_a_score = 0;
								for (int i = 0; i < num_of_split_a_cards; i++) {
									split_a_score += card_value(split_a_cards[i]);
								}
			
								// Check for ace cards in player hand
								int ace_cards = 0;
								for (int i = 0; i < num_of_split_a_cards; i++) {
									if (strcmp(split_a_cards[i].rank, "Ace") == 0) ace_cards += 1;
								}
								while (ace_cards > 0 && split_a_score > 21) {
									split_a_score -= 10;
									ace_cards -= 1;
								}

								// Drawing
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(dealer_cards[0], dealer_rect_1);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								draw_card(split_a_cards[0], player_split_6);
								draw_card(split_a_cards[1], player_split_7);
								draw_card(split_b_cards[0], player_split_1);
								
								if (num_of_split_a_cards >= 3) {
									if ((double_down_split_a) || (triple_down_split_a)) {
										rotate_flag = true;
										draw_card(split_a_cards[2], player_split_8);
										rotate_flag = false;
									}
									else {draw_card(split_a_cards[2], player_split_8);}
								}
								if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
								if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
								
								// Check if player bust, double down, or triple down
								if (split_a_score > 21) break;
								if ((double_down_split_a) || (triple_down_split_a)) break;
								
								// Check for 77 7 distributed over split hands
								if ((strcmp(split_a_cards[0].rank, "7") == 0) && \
									(strcmp(split_a_cards[1].rank, "7") == 0) && \
									(strcmp(split_b_cards[0].rank, "7") == 0)) {
									seven_flag = true;
									break;
								}   

								// Check for five card charlie
								if (num_of_split_a_cards == 5) break;
								
								if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
									if (ir.x >= pos_1button_rect[0] && ir.x <= pos_1button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,StandGrey_Button,&texObj);
											draw_button_mask(stand_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,StandLight_Button,&texObj);
											draw_button_mask(stand_button_rect);	
										}
										if (released & WPAD_BUTTON_A) break;				
									}
									if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,HitGrey_Button,&texObj);
											draw_button_mask(hit_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,HitLight_Button,&texObj);
											draw_button_mask(hit_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											
											// Draw the player pointer
											draw_player_pointer();
							
											GX_DrawDone();
											GX_CopyDisp(xfb, GX_FALSE);
											VIDEO_WaitVSync();
											
											// Deal 1 card to the split_a player
											split_a_cards[num_of_split_a_cards] = deck[top_card_of_deck];
											--top_card_of_deck;
											++num_of_split_a_cards;
											card_count_running += count_value(split_a_cards[(num_of_split_a_cards - 1)]);
											
											ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
															(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
											
											// Woosh the third, fourth, or fifth player card					
											if (num_of_split_a_cards == 3) woosh(player_split_8);
											if (num_of_split_a_cards == 4) woosh(player_split_9);
											if (num_of_split_a_cards == 5) woosh(player_split_10);
										}
									}
									if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,DoubleGrey_Button,&texObj);
											draw_button_mask(double_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,DoubleLight_Button,&texObj);
											draw_button_mask(double_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											if (num_of_split_a_cards >= 3) {
												
												// Draw the player pointer
												draw_player_pointer();
							
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 14);	
												printf("Can't Double Down after Hit.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													
													if (num_of_split_a_cards >= 3) draw_card(split_a_cards[2], player_split_8);				
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}
												
												released = 0;
											}
											else {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_FALSE);
												VIDEO_WaitVSync();
							
												double_down_split_a = true;
												player_coins -= bet_current;
												
												// Deal 1 card to the split_a player
												split_a_cards[num_of_split_a_cards] = deck[top_card_of_deck];
												--top_card_of_deck;
												++num_of_split_a_cards;
												card_count_running += count_value(split_a_cards[(num_of_split_a_cards - 1)]);
												
												ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
																(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
																
												// Woosh the third split_a card
												woosh(player_split_8);
											}
										}
									}
									if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,TripleGrey_Button,&texObj);
											draw_button_mask(triple_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,TripleLight_Button,&texObj);
											draw_button_mask(triple_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											if (num_of_split_a_cards >= 3) {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 14);	
												printf("Can't Triple Down after Hit.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													
													if (num_of_split_a_cards >= 3) draw_card(split_a_cards[2], player_split_8);				
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}

												released = 0;
											}
											else if (split_a_score < 9 || split_a_score > 11) {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 9);	
												printf("Can only Triple Down on Hard 9, 10, 11.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													
													if (num_of_split_a_cards >= 3) draw_card(split_a_cards[2], player_split_8);				
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}
												
												released = 0;
											}
											else {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_FALSE);
												VIDEO_WaitVSync();
												
												triple_down_split_a = true;
												player_coins -= bet_current;
												
												// Deal 1 card to the split_a player
												split_a_cards[num_of_split_a_cards] = deck[top_card_of_deck];
												--top_card_of_deck;
												++num_of_split_a_cards;
												card_count_running += count_value(split_a_cards[(num_of_split_a_cards - 1)]);
												
												ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
																(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
																
												// Woosh the third split_a card
												woosh(player_split_8);
											}
										}
									}
									if (ir.x >= pos_5button_rect[0] && ir.x <= pos_5button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,SplitGrey_Button,&texObj);
											draw_button_mask(split_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,SplitLight_Button,&texObj);
											draw_button_mask(split_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											
											// Draw the player pointer
											draw_player_pointer();
												
											GX_DrawDone();
											GX_CopyDisp(xfb, GX_TRUE);
											VIDEO_WaitVSync();
											
											set_pos(1, 16);	
											printf("Can't Split after Split.");
											
											// Play mp3 file
											MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
											while (MP3Player_IsPlaying()) {
												
												WPAD_ScanPads();
												WPAD_IR(0, &ir);
													
												// Draw the main console at position
												fflush(stdout);
												gx_console_draw(con_stdout, 4, 380);

												// Function to setup the vertex descriptor for sprites
												setup_vertex();
												fill_screen_buttons();
												
												draw_card(dealer_cards[0], dealer_rect_1);
							
												// Dealer's second card is not shown
												draw_card_back(dealer_rect_2);
												
												draw_card(split_a_cards[0], player_split_6);
												draw_card(split_a_cards[1], player_split_7);
												draw_card(split_b_cards[0], player_split_1);
												
												if (num_of_split_a_cards >= 3) draw_card(split_a_cards[2], player_split_8);				
												if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
											}
										}
									}
								}
								
								// Draw the player pointer
								draw_player_pointer();
		
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}	
							
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_TRUE);
							VIDEO_WaitVSync();
	
							// Deal 1 card to the split_b player
							split_b_cards[num_of_split_b_cards] = deck[top_card_of_deck];
							--top_card_of_deck;
							++num_of_split_b_cards;
							card_count_running += count_value(split_b_cards[(num_of_split_b_cards - 1)]);

							// Make sure the framebuffer is ready to woosh with mirror effect
							fflush(stdout);
							gx_console_draw(con_stdout, 4, 380);

							// Function to setup the vertex descriptor for sprites
							setup_vertex();
							fill_screen_buttons();
							draw_card(dealer_cards[0], dealer_rect_1);
							
							// Dealer's second card is not shown
							draw_card_back(dealer_rect_2);
							
							draw_card(split_a_cards[0], player_split_6);
							draw_card(split_a_cards[1], player_split_7);
							draw_card(split_b_cards[0], player_split_1);
							
							if (num_of_split_a_cards >= 3) {
								if ((double_down_split_a) || (triple_down_split_a)) {
									rotate_flag = true;
									draw_card(split_a_cards[2], player_split_8);
									rotate_flag = false;
								}
								else {draw_card(split_a_cards[2], player_split_8);}
							}
							if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
							if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
								
							// Draw the player pointer
							draw_player_pointer();
							
							GX_DrawDone();
							GX_CopyDisp(xfb, GX_FALSE);
							VIDEO_WaitVSync();
					
							ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
											(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);

							woosh(player_split_2);

//---------------------------------------------------------------------------------
// Split b gets to hit, stand, double, triple, or split
//---------------------------------------------------------------------------------
					
							// Split b gets to hit, stand, or double down
							while (true) {
								
								set_pos(1, 1);
								printf("                                                        ");
								
								WPAD_ScanPads();
								u32 pressed = WPAD_ButtonsHeld(0);
								u32 released = WPAD_ButtonsUp(0);
								WPAD_IR(0, &ir);
								
								if (pressed & WPAD_BUTTON_HOME) goto Main_menu_section;
								
								// Calculate player_a score based on card value
								split_b_score = 0;
								for (int i = 0; i < num_of_split_b_cards; i++) {
									split_b_score += card_value(split_b_cards[i]);
								}
			
								// Check for ace cards in player hand
								int ace_cards = 0;
								for (int i = 0; i < num_of_split_b_cards; i++) {
									if (strcmp(split_b_cards[i].rank, "Ace") == 0) ace_cards += 1;
								}
								while (ace_cards > 0 && split_b_score > 21) {
									split_b_score -= 10;
									ace_cards -= 1;
								}

								// Drawing
								fflush(stdout);
								gx_console_draw(con_stdout, 4, 380);

								// Function to setup the vertex descriptor for sprites
								setup_vertex();
								fill_screen_buttons();
								draw_card(dealer_cards[0], dealer_rect_1);
								
								// Dealer's second card is not shown
								draw_card_back(dealer_rect_2);
								
								draw_card(split_a_cards[0], player_split_6);
								draw_card(split_a_cards[1], player_split_7);
								draw_card(split_b_cards[0], player_split_1);
								draw_card(split_b_cards[1], player_split_2);	
								
								if (num_of_split_a_cards >= 3) {
									if ((double_down_split_a) || (triple_down_split_a)) {
										rotate_flag = true;
										draw_card(split_a_cards[2], player_split_8);
										rotate_flag = false;
									}
									else {draw_card(split_a_cards[2], player_split_8);}
								}
								if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
								if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
								
								if (num_of_split_b_cards >= 3) {
									if ((double_down_split_b) || (triple_down_split_b)) {
										rotate_flag = true;
										draw_card(split_b_cards[2], player_split_3);
										rotate_flag = false;
									}
									else {draw_card(split_b_cards[2], player_split_3);}
								}
								if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
								if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
								
								// Check if player bust, double down, or triple down
								if (split_b_score > 21) break;
								if ((double_down_split_b) || (triple_down_split_b)) break;
									
								// Check for 777
								if (seven_flag) break;
								
								// Check for five card charlie
								if (num_of_split_b_cards == 5) break;
								
								if (ir.y >= pos_1button_rect[1] && ir.y <= pos_1button_rect[3]) {
									if (ir.x >= pos_1button_rect[0] && ir.x <= pos_1button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,StandGrey_Button,&texObj);
											draw_button_mask(stand_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,StandLight_Button,&texObj);
											draw_button_mask(stand_button_rect);	
										}
										if (released & WPAD_BUTTON_A) break;				
									}
									if (ir.x >= pos_2button_rect[0] && ir.x <= pos_2button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,HitGrey_Button,&texObj);
											draw_button_mask(hit_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,HitLight_Button,&texObj);
											draw_button_mask(hit_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											
											// Draw the player pointer
											draw_player_pointer();
											
											GX_DrawDone();
											GX_CopyDisp(xfb, GX_FALSE);
											VIDEO_WaitVSync();
												
											// Deal 1 card to the split_b player
											split_b_cards[num_of_split_b_cards] = deck[top_card_of_deck];
											--top_card_of_deck;
											++num_of_split_b_cards;
											card_count_running += count_value(split_b_cards[(num_of_split_b_cards - 1)]);
											
											ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
															(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
											
											// Woosh the third, fourth, or fifth player card					
											if (num_of_split_b_cards == 3) woosh(player_split_3);
											if (num_of_split_b_cards == 4) woosh(player_split_4);
											if (num_of_split_b_cards == 5) woosh(player_split_5);
										}
									}
									if (ir.x >= pos_3button_rect[0] && ir.x <= pos_3button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,DoubleGrey_Button,&texObj);
											draw_button_mask(double_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,DoubleLight_Button,&texObj);
											draw_button_mask(double_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											if (num_of_split_b_cards >= 3) {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 14);	
												printf("Can't Double Down after Hit.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													draw_card(split_b_cards[1], player_split_2);
													
													if (num_of_split_a_cards >= 3) {
														if ((double_down_split_a) || (triple_down_split_a)) {
															rotate_flag = true;
															draw_card(split_a_cards[2], player_split_8);
															rotate_flag = false;
														}
														else {draw_card(split_a_cards[2], player_split_8);}
													}
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
													
													if (num_of_split_b_cards >= 3) draw_card(split_b_cards[2], player_split_3);
													if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}

												released = 0;
											}
											else {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_FALSE);
												VIDEO_WaitVSync();
												
												double_down_split_b = true;
												player_coins -= bet_current;
												
												// Deal 1 card to the split_b player
												split_b_cards[num_of_split_b_cards] = deck[top_card_of_deck];
												--top_card_of_deck;
												++num_of_split_b_cards;
												card_count_running += count_value(split_b_cards[(num_of_split_b_cards - 1)]);
												
												ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
																(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
																
												// Woosh the third split_b card
												woosh(player_split_3);
											}
										}
									}
									if (ir.x >= pos_4button_rect[0] && ir.x <= pos_4button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,TripleGrey_Button,&texObj);
											draw_button_mask(triple_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,TripleLight_Button,&texObj);
											draw_button_mask(triple_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											if (num_of_split_b_cards >= 3) {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 14);	
												printf("Can't Triple Down after Hit.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													draw_card(split_b_cards[1], player_split_2);
													
													if (num_of_split_a_cards >= 3) {
														if ((double_down_split_a) || (triple_down_split_a)) {
															rotate_flag = true;
															draw_card(split_a_cards[2], player_split_8);
															rotate_flag = false;
														}
														else {draw_card(split_a_cards[2], player_split_8);}
													}
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
													
													if (num_of_split_b_cards >= 3) draw_card(split_b_cards[2], player_split_3);
													if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}

												released = 0;
											}
											else if (split_b_score < 9 || split_b_score > 11) {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
												
												set_pos(1, 9);	
												printf("Can only Triple Down on Hard 9, 10, 11.");
												
												// Play mp3 file
												MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
												while (MP3Player_IsPlaying()) {
													
													WPAD_ScanPads();
													WPAD_IR(0, &ir);
													
													// Draw the main console at position
													fflush(stdout);
													gx_console_draw(con_stdout, 4, 380);

													// Function to setup the vertex descriptor for sprites
													setup_vertex();
													fill_screen_buttons();
													
													draw_card(dealer_cards[0], dealer_rect_1);
								
													// Dealer's second card is not shown
													draw_card_back(dealer_rect_2);
													
													draw_card(split_a_cards[0], player_split_6);
													draw_card(split_a_cards[1], player_split_7);
													draw_card(split_b_cards[0], player_split_1);
													draw_card(split_b_cards[1], player_split_2);
													
													if (num_of_split_a_cards >= 3) {
														if ((double_down_split_a) || (triple_down_split_a)) {
															rotate_flag = true;
															draw_card(split_a_cards[2], player_split_8);
															rotate_flag = false;
														}
														else {draw_card(split_a_cards[2], player_split_8);}
													}
													if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
													if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
													
													if (num_of_split_b_cards >= 3) draw_card(split_b_cards[2], player_split_3);
													if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
													
													// Draw the player pointer
													draw_player_pointer();
													
													GX_DrawDone();
													GX_CopyDisp(xfb, GX_TRUE);
													VIDEO_WaitVSync();
												}
												
												released = 0;
											}
											else {
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_FALSE);
												VIDEO_WaitVSync();
												
												triple_down_split_b = true;
												player_coins -= bet_current;
												
												// Deal 1 card to the split_b player
												split_b_cards[num_of_split_b_cards] = deck[top_card_of_deck];
												--top_card_of_deck;
												++num_of_split_b_cards;
												card_count_running += count_value(split_b_cards[(num_of_split_b_cards - 1)]);
												
												ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
																(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
																
												// Woosh the third split_b card
												woosh(player_split_3);
											}
										}
									}
									if (ir.x >= pos_5button_rect[0] && ir.x <= pos_5button_rect[2]) {
										if (pressed & WPAD_BUTTON_A) {
											TPL_GetTexture(&spriteTPL,SplitGrey_Button,&texObj);
											draw_button_mask(split_button_rect);
										}
										else {
											TPL_GetTexture(&spriteTPL,SplitLight_Button,&texObj);
											draw_button_mask(split_button_rect);	
										}
										if (released & WPAD_BUTTON_A) {
											
											// Draw the player pointer
											draw_player_pointer();
												
											GX_DrawDone();
											GX_CopyDisp(xfb, GX_TRUE);
											VIDEO_WaitVSync();
											
											set_pos(1, 16);	
											printf("Can't Split after Split.");
											
											// Play mp3 file
											MP3Player_PlayBuffer(Error_mp3, Error_mp3_size, NULL);
											while (MP3Player_IsPlaying()) {
												
												WPAD_ScanPads();
												WPAD_IR(0, &ir);
												
												// Draw the main console at position
												fflush(stdout);
												gx_console_draw(con_stdout, 4, 380);

												// Function to setup the vertex descriptor for sprites
												setup_vertex();
												fill_screen_buttons();
												
												draw_card(dealer_cards[0], dealer_rect_1);
							
												// Dealer's second card is not shown
												draw_card_back(dealer_rect_2);
												
												draw_card(split_a_cards[0], player_split_6);
												draw_card(split_a_cards[1], player_split_7);
												draw_card(split_b_cards[0], player_split_1);
												draw_card(split_b_cards[1], player_split_2);
												
												if (num_of_split_a_cards >= 3) {
													if ((double_down_split_a) || (triple_down_split_a)) {
														rotate_flag = true;
														draw_card(split_a_cards[2], player_split_8);
														rotate_flag = false;
													}
													else {draw_card(split_a_cards[2], player_split_8);}
												}
												if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
												if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
												
												if (num_of_split_b_cards >= 3) draw_card(split_b_cards[2], player_split_3);
												if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
												
												// Draw the player pointer
												draw_player_pointer();
												
												GX_DrawDone();
												GX_CopyDisp(xfb, GX_TRUE);
												VIDEO_WaitVSync();
											}
										}
									}
								}
								
								// Draw the player pointer
								draw_player_pointer();
								
								GX_DrawDone();
								GX_CopyDisp(xfb, GX_TRUE);
								VIDEO_WaitVSync();
							}
							
							break;
						}
					}	
				}
			}
			
			// Draw the player pointer
			draw_player_pointer();
			
			GX_DrawDone();
			GX_CopyDisp(xfb, GX_TRUE);
			VIDEO_WaitVSync();
		}
		
		// Draw the player pointer
		draw_player_pointer();
		
		GX_DrawDone();
		GX_CopyDisp(xfb, GX_TRUE);
		VIDEO_WaitVSync();
			
//---------------------------------------------------------------------------------
// Dealer gets to hit or stand
//---------------------------------------------------------------------------------
		
		// Get ready to only card count the 2nd dealer card once if it's shown
        once_count_2nd_dealer_card = 1;
		
		// Dealer gets to hit or stand
        while (true) {
			
			WPAD_ScanPads();
			WPAD_IR(0, &ir);
			
			// Calculate dealer score
			dealer_score = 0;
			for (int i = 0; i < num_of_dealer_cards; i++) {
				dealer_score += card_value(dealer_cards[i]);
			}
			
			// For card counting, only count the dealer's 2nd card once
            if (once_count_2nd_dealer_card == 1) {
                card_count_running += count_value(dealer_cards[1]);
				once_count_2nd_dealer_card += 1;
			}
			
			// Check if player has blackjack
            if (player_score == 21 && num_of_player_cards == 2) {
                
				// Draw the main console at position
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(player_cards[0], player_rect_1);
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(player_cards[1], player_rect_2);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
				
                break;
			}
			
			// Check if player bust or both of the splits bust
            if (player_score > 21) break;
            if (split_a_score > 21 && split_b_score > 21) break;
			
			// Check for 777 or 77 7
            if (seven_flag) break;
			
			// Check for five card charlie
            if (num_of_player_cards == 5) {
                
				// Draw the main console at position
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(player_cards[0], player_rect_1);
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(player_cards[1], player_rect_2);
				draw_card(dealer_cards[1], dealer_rect_2);
				draw_card(player_cards[2], player_rect_3);
				draw_card(player_cards[3], player_rect_4);
				draw_card(player_cards[4], player_rect_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
				
                break;
			}
			if (num_of_split_a_cards == 5 && num_of_split_b_cards == 5) break;
			
			// Check for ace cards in dealer hand
			int ace_cards = 0;
			for (int i = 0; i < num_of_dealer_cards; i++) {
				if (strcmp(dealer_cards[i].rank, "Ace") == 0) ace_cards += 1;
			}
			while (ace_cards > 0 && dealer_score > 21) {
				dealer_score -= 10;
				ace_cards -= 1;
			}
			
			// Drawing dealer cards
			fflush(stdout);
			gx_console_draw(con_stdout, 4, 380);

			// Function to setup the vertex descriptor for sprites
			setup_vertex();
			fill_screen_buttons();
			draw_card(dealer_cards[0], dealer_rect_1);
			draw_card(dealer_cards[1], dealer_rect_2);
			
			if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
			if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
			if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);
			
			// Drawing player cards if not split
            if (!split_flag) {
				draw_card(player_cards[0], player_rect_1);
				draw_card(player_cards[1], player_rect_2);
				
				if (num_of_player_cards >= 3) {
					if ((double_down_flag) || (triple_down_flag)) {
						rotate_flag = true;
						draw_card(player_cards[2], player_rect_3);
						rotate_flag = false;
					}
					else {draw_card(player_cards[2], player_rect_3);}
				}
				if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
				if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
			}
			
			// Drawing player cards if split
            if (split_flag) {
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
			}
			
			// Draw the player pointer
			draw_player_pointer();
			
			GX_DrawDone();
			GX_CopyDisp(xfb, GX_TRUE);
			VIDEO_WaitVSync();
			
			// Check for five card dealer
            if (num_of_dealer_cards == 5) break;
			
			// Check if dealer above 17
            if (dealer_score > 17) break;
			
			// Check remaining soft Aces from earlier Ace check for Soft 17
            if (dealer_score == 17) {
                if (ace_cards == 0) break;
            }
					
			// Deal 1 card to the dealer
			dealer_cards[num_of_dealer_cards] = deck[top_card_of_deck];
			--top_card_of_deck;
			++num_of_dealer_cards;
			card_count_running += count_value(dealer_cards[(num_of_dealer_cards - 1)]);
			
			// Make sure the framebuffer is ready to woosh with mirror effect
			fflush(stdout);
			gx_console_draw(con_stdout, 4, 380);

			// Function to setup the vertex descriptor for sprites
			setup_vertex();
			fill_screen_buttons();
			draw_card(dealer_cards[0], dealer_rect_1);
			draw_card(dealer_cards[1], dealer_rect_2);
			
			if (num_of_dealer_cards >= 4) draw_card(dealer_cards[2], dealer_rect_3);
			if (num_of_dealer_cards >= 5) draw_card(dealer_cards[3], dealer_rect_4);
			
			// Drawing player cards if not split
            if (!split_flag) {
				draw_card(player_cards[0], player_rect_1);
				draw_card(player_cards[1], player_rect_2);
				
				if (num_of_player_cards >= 3) {
					if ((double_down_flag) || (triple_down_flag)) {
						rotate_flag = true;
						draw_card(player_cards[2], player_rect_3);
						rotate_flag = false;
					}
					else {draw_card(player_cards[2], player_rect_3);}
				}
				if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
				if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
			}
			
			// Drawing player cards if split
            if (split_flag) {
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
			}
			
			// Draw the player pointer
			draw_player_pointer();
			
			GX_DrawDone();
			GX_CopyDisp(xfb, GX_FALSE);
			VIDEO_WaitVSync();
			
			ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
							(void*)CardDeal_raw, CardDeal_raw_size, 255, 255, NULL);
			
			// Woosh the third, fourth, or fifth dealer card	
			if (num_of_dealer_cards == 3) woosh(dealer_rect_3);
			if (num_of_dealer_cards == 4) woosh(dealer_rect_4);
			if (num_of_dealer_cards == 5) woosh(dealer_rect_5);
		}
		
//---------------------------------------------------------------------------------
// Insurance results
//---------------------------------------------------------------------------------

		// Insurance results
		if (insurance_flag) {
			if (dealer_score == 21 && num_of_dealer_cards == 2) {
				
				player_coins += bet_current;
				set_pos(1, 21);
				printf("Insurance paid!");
					
				// Play mp3 file
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
				while (MP3Player_IsPlaying()) {
					
					WPAD_ScanPads();
					WPAD_IR(0, &ir);
					
					fflush(stdout);
					gx_console_draw(con_stdout, 4, 380);

					// Function to setup the vertex descriptor for sprites
					setup_vertex();
					fill_screen_buttons();
					draw_card(dealer_cards[0], dealer_rect_1);
					draw_card(dealer_cards[1], dealer_rect_2);
					
					if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
					if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
					if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);
					
					// Drawing player cards if not split
					if (!split_flag) {  
						draw_card(player_cards[0], player_rect_1);
						draw_card(player_cards[1], player_rect_2);
						
						if (num_of_player_cards >= 3) {
							if ((double_down_flag) || (triple_down_flag)) {
								rotate_flag = true;
								draw_card(player_cards[2], player_rect_3);
								rotate_flag = false;
							}
							else {draw_card(player_cards[2], player_rect_3);}
						}
						if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
						if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
					}
					
					// Drawing player cards if split
					if (split_flag) {
						draw_card(split_a_cards[0], player_split_6);
						draw_card(split_a_cards[1], player_split_7);
						draw_card(split_b_cards[0], player_split_1);
						draw_card(split_b_cards[1], player_split_2);	
						
						if (num_of_split_a_cards >= 3) {
							if ((double_down_split_a) || (triple_down_split_a)) {
								rotate_flag = true;
								draw_card(split_a_cards[2], player_split_8);
								rotate_flag = false;
							}
							else {draw_card(split_a_cards[2], player_split_8);}
						}
						if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
						if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
						
						if (num_of_split_b_cards >= 3) {
							if ((double_down_split_b) || (triple_down_split_b)) {
								rotate_flag = true;
								draw_card(split_b_cards[2], player_split_3);
								rotate_flag = false;
							}
							else {draw_card(split_b_cards[2], player_split_3);}
						}
						if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
						if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
					}
					
					// Draw the player pointer
					draw_player_pointer();
					
					GX_DrawDone();
					GX_CopyDisp(xfb, GX_TRUE);
					VIDEO_WaitVSync();
				}
				
				// Play mp3 file
				MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
				while (MP3Player_IsPlaying()) {
					
					WPAD_ScanPads();
					WPAD_IR(0, &ir);
					
					fflush(stdout);
					gx_console_draw(con_stdout, 4, 380);

					// Function to setup the vertex descriptor for sprites
					setup_vertex();
					fill_screen_buttons();
					draw_card(dealer_cards[0], dealer_rect_1);
					draw_card(dealer_cards[1], dealer_rect_2);
					
					if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
					if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
					if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);
					
					// Drawing player cards if not split
					if (!split_flag) {  
						draw_card(player_cards[0], player_rect_1);
						draw_card(player_cards[1], player_rect_2);
						
						if (num_of_player_cards >= 3) {
							if ((double_down_flag) || (triple_down_flag)) {
								rotate_flag = true;
								draw_card(player_cards[2], player_rect_3);
								rotate_flag = false;
							}
							else {draw_card(player_cards[2], player_rect_3);}
						}
						if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
						if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
					}
					
					// Drawing player cards if split
					if (split_flag) {
						draw_card(split_a_cards[0], player_split_6);
						draw_card(split_a_cards[1], player_split_7);
						draw_card(split_b_cards[0], player_split_1);
						draw_card(split_b_cards[1], player_split_2);	
						
						if (num_of_split_a_cards >= 3) {
							if ((double_down_split_a) || (triple_down_split_a)) {
								rotate_flag = true;
								draw_card(split_a_cards[2], player_split_8);
								rotate_flag = false;
							}
							else {draw_card(split_a_cards[2], player_split_8);}
						}
						if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
						if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
						
						if (num_of_split_b_cards >= 3) {
							if ((double_down_split_b) || (triple_down_split_b)) {
								rotate_flag = true;
								draw_card(split_b_cards[2], player_split_3);
								rotate_flag = false;
							}
							else {draw_card(split_b_cards[2], player_split_3);}
						}
						if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
						if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
					}
					
					// Draw the player pointer
					draw_player_pointer();
					
					GX_DrawDone();
					GX_CopyDisp(xfb, GX_TRUE);
					VIDEO_WaitVSync();
				}
			}
		}
		
		set_pos(1, 1);
		printf("                                                        ");

//---------------------------------------------------------------------------------
// Results if not split
//---------------------------------------------------------------------------------
		
		// Results if not split
		if (!split_flag) {
			if (player_score > 21) {
				set_pos(1, 14);
				printf("Player has bust, Dealer wins!");
			}
			else if (player_score != dealer_score && player_score == 21 && num_of_player_cards == 2) {
				if (strcmp(player_cards[0].suit, player_cards[1].suit) == 0) {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Suited Blackjack! Player wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
				else {
					player_coins += bet_current * 2.5;
					set_pos(1, 17);
					printf("Blackjack! Player wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}
			
			// Check for 777
			else if (seven_flag) {
				player_coins += bet_current * 4;
				set_pos(1, 20);
				printf("777! Player wins!");
				MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
				ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
								(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
			}

			// Check for five card charlie
			else if (num_of_player_cards == 5) {
				if (dealer_score == 21 && num_of_dealer_cards == 2) {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
				else {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Five-Card Charlie! Player wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}

			// Check for dealer blackjack and player 21
			else if (dealer_score == 21 && num_of_dealer_cards == 2) {
				if (player_score == 21 && num_of_player_cards == 2) {
					player_coins += bet_current;
					set_pos(1, 11);
					printf("Result is a Push, bet is returned.");
					MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
				}
				else {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
			}

			else if (dealer_score > 21) {
				if (double_down_flag) player_coins += bet_current * 4;
				else if (triple_down_flag) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 14);
				printf("Dealer has bust, Player wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (player_score > dealer_score) {
				if (double_down_flag) player_coins += bet_current * 4;
				else if (triple_down_flag) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 22);
				printf("Player wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (dealer_score > player_score) {
				set_pos(1, 22);
				printf("Dealer wins!");
			}
			else {
				if (double_down_flag) player_coins += bet_current * 2;
				else if (triple_down_flag) player_coins += bet_current * 3;
				else player_coins += bet_current;
				
				set_pos(1, 11);
				printf("Result is a Push, bet is returned.");
				MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
			}
			
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);
				
				draw_card(player_cards[0], player_rect_1);
				draw_card(player_cards[1], player_rect_2);
				
				if (num_of_player_cards >= 3) {
					if ((double_down_flag) || (triple_down_flag)) {
						rotate_flag = true;
						draw_card(player_cards[2], player_rect_3);
						rotate_flag = false;
					}
					else {draw_card(player_cards[2], player_rect_3);}
				}
				if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
				if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
			
			MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);
				
				draw_card(player_cards[0], player_rect_1);
				draw_card(player_cards[1], player_rect_2);
				
				if (num_of_player_cards >= 3) {
					if ((double_down_flag) || (triple_down_flag)) {
						rotate_flag = true;
						draw_card(player_cards[2], player_rect_3);
						rotate_flag = false;
					}
					else {draw_card(player_cards[2], player_rect_3);}
				}
				if (num_of_player_cards >= 4) draw_card(player_cards[3], player_rect_4);
				if (num_of_player_cards >= 5) draw_card(player_cards[4], player_rect_5);	
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
		}

//---------------------------------------------------------------------------------
// Results if split
//---------------------------------------------------------------------------------
		
		// Results if split
		if (split_flag) {
			
			// Split a results
			if (split_a_score > 21) {
				set_pos(1, 13);
				printf("Split A has bust, Dealer wins!");
			}
			else if (split_a_score != dealer_score && split_a_score == 21 && num_of_split_a_cards == 2) {
				if (strcmp(split_a_cards[0].suit, split_a_cards[1].suit) == 0) {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Suited Blackjack! Split A wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
				else {
					player_coins += bet_current * 2.5;
					set_pos(1, 16);
					printf("Blackjack! Split A wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}
			
			// Check for 777
			else if (seven_flag) {
				player_coins += bet_current * 4;
				set_pos(1, 20);
				printf("777! Player wins!");
				MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
				ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
								(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
			}

			// Check for five card charlie
			else if (num_of_split_a_cards == 5) {
				if (dealer_score == 21 && num_of_dealer_cards == 2) {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
				else {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Five-Card Charlie! Split A wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}

			// Check for dealer blackjack and player 21
			else if (dealer_score == 21 && num_of_dealer_cards == 2) {
				if (split_a_score == 21 && num_of_split_a_cards == 2) {
					player_coins += bet_current;
					set_pos(1, 11);
					printf("Result is a Push, bet A is returned.");
					MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
				}
				else {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
			}

			else if (dealer_score > 21) {
				if (double_down_split_a) player_coins += bet_current * 4;
				else if (triple_down_split_a) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 13);
				printf("Dealer has bust, Split A wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (split_a_score > dealer_score) {
				if (double_down_split_a) player_coins += bet_current * 4;
				else if (triple_down_split_a) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 22);
				printf("Split A wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (dealer_score > split_a_score) {
				set_pos(1, 22);
				printf("Dealer wins!");
			}
			else {
				if (double_down_split_a) player_coins += bet_current * 2;
				else if (triple_down_split_a) player_coins += bet_current * 3;
				else player_coins += bet_current;
				
				set_pos(1, 11);
				printf("Result is a Push, bet A is returned.");
				MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
			}
			
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);	
				
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
			
			MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);	
				
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
			
			set_pos(1, 1);
			printf("                                                        ");

			for (int i = 0; i < 2; i++) {
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);	
				
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
			
			// Split b results
			if (split_b_score > 21) {
				set_pos(1, 13);
				printf("Split B has bust, Dealer wins!");
			}
			else if (split_b_score != dealer_score && split_b_score == 21 && num_of_split_b_cards == 2) {
				if (strcmp(split_b_cards[0].suit, split_b_cards[1].suit) == 0) {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Suited Blackjack! Split B wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
				else {
					player_coins += bet_current * 2.5;
					set_pos(1, 16);
					printf("Blackjack! Split B wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}
			
			// Check for 777
			else if (seven_flag) {
				set_pos(1, 20);
				printf("777! Player wins!");
			}

			// Check for five card charlie
			else if (num_of_split_b_cards == 5) {
				if (dealer_score == 21 && num_of_dealer_cards == 2) {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
				else {
					player_coins += bet_current * 3;
					set_pos(1, 13);
					printf("Five-Card Charlie! Split B wins!");
					MP3Player_PlayBuffer(Cheer_mp3, Cheer_mp3_size, NULL);
					ASND_SetVoice(	ASND_GetFirstUnusedVoice(), VOICE_STEREO_16BIT, 44100, 0, \
									(void*)CoinChange_raw, CoinChange_raw_size, 255, 255, NULL);
				}
			}

			// Check for dealer blackjack and player 21
			else if (dealer_score == 21 && num_of_dealer_cards == 2) {
				if (split_b_score == 21 && num_of_split_b_cards == 2) {
					player_coins += bet_current;
					set_pos(1, 11);
					printf("Result is a Push, bet B is returned.");
					MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
				}
				else {
					set_pos(1, 17);
					printf("Blackjack! Dealer wins!");
				}
			}

			else if (dealer_score > 21) {
				if (double_down_split_b) player_coins += bet_current * 4;
				else if (triple_down_split_b) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 13);
				printf("Dealer has bust, Split B wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (split_b_score > dealer_score) {
				if (double_down_split_b) player_coins += bet_current * 4;
				else if (triple_down_split_b) player_coins += bet_current * 6;
				else player_coins += bet_current * 2;
				
				set_pos(1, 22);
				printf("Split B wins!");
				MP3Player_PlayBuffer(CoinChange_mp3, CoinChange_mp3_size, NULL);
			}
			else if (dealer_score > split_b_score) {
				set_pos(1, 22);
				printf("Dealer wins!");
			}
			else {
				if (double_down_split_b) player_coins += bet_current * 2;
				else if (triple_down_split_b) player_coins += bet_current * 3;
				else player_coins += bet_current;
				
				set_pos(1, 11);
				printf("Result is a Push, bet B is returned.");
				MP3Player_PlayBuffer(ChipReturn_mp3, ChipReturn_mp3_size, NULL);
			}
			
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);	
				
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
			
			MP3Player_PlayBuffer(TwoSecSilence_mp3, TwoSecSilence_mp3_size, NULL);
			while (MP3Player_IsPlaying()) {
					
				WPAD_ScanPads();
				WPAD_IR(0, &ir);
				
				fflush(stdout);
				gx_console_draw(con_stdout, 4, 380);

				// Function to setup the vertex descriptor for sprites
				setup_vertex();
				fill_screen_buttons();
				draw_card(dealer_cards[0], dealer_rect_1);
				draw_card(dealer_cards[1], dealer_rect_2);
				
				if (num_of_dealer_cards >= 3) draw_card(dealer_cards[2], dealer_rect_3);
				if (num_of_dealer_cards >= 4) draw_card(dealer_cards[3], dealer_rect_4);
				if (num_of_dealer_cards >= 5) draw_card(dealer_cards[4], dealer_rect_5);	
				
				draw_card(split_a_cards[0], player_split_6);
				draw_card(split_a_cards[1], player_split_7);
				draw_card(split_b_cards[0], player_split_1);
				draw_card(split_b_cards[1], player_split_2);	
				
				if (num_of_split_a_cards >= 3) {
					if ((double_down_split_a) || (triple_down_split_a)) {
						rotate_flag = true;
						draw_card(split_a_cards[2], player_split_8);
						rotate_flag = false;
					}
					else {draw_card(split_a_cards[2], player_split_8);}
				}
				if (num_of_split_a_cards >= 4) draw_card(split_a_cards[3], player_split_9);
				if (num_of_split_a_cards >= 5) draw_card(split_a_cards[4], player_split_10);
				
				if (num_of_split_b_cards >= 3) {
					if ((double_down_split_b) || (triple_down_split_b)) {
						rotate_flag = true;
						draw_card(split_b_cards[2], player_split_3);
						rotate_flag = false;
					}
					else {draw_card(split_b_cards[2], player_split_3);}
				}
				if (num_of_split_b_cards >= 4) draw_card(split_b_cards[3], player_split_4);
				if (num_of_split_b_cards >= 5) draw_card(split_b_cards[4], player_split_5);
				
				// Draw the player pointer
				draw_player_pointer();
				
				GX_DrawDone();
				GX_CopyDisp(xfb, GX_TRUE);
				VIDEO_WaitVSync();
			}
		}
	}	

	goto Main_menu_section;
}
