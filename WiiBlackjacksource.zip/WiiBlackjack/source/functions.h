#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <gccore.h>
#include <ogc/tpl.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <asndlib.h>
#include <mp3player.h>

#include "variables.h"
#include "constants.h"

#include "textures_tpl.h"		// Generated texture files at compile
#include "textures.h"

// Function declarations
void set_pos(int row, int column);
int count_array(const char **arr);
void new_deck(Card temp_deck[52]);
void fresh_deck(void);
int card_value(Card card);
int count_value(Card card);
void setup_vertex(void);
void draw_sprite_tex(int x, int y, int width, int height);
void draw_sprite_rotate(int x, int y, int width, int height);
void draw_card(Card card, const int rect[]);
void draw_card_back(const int rect[]);
void draw_strategy(const int rect[]);
void draw_table(const int rect[]);
void draw_button_mask(const int rect[]);
void draw_player_pointer(void);
void fill_screen_main_menu(void);
void fill_screen_bet(void);
void fill_screen_buttons(void);
void fill_screen_insurance(void);
void fill_screen_options(void);
void woosh(const int destination_rect[]);
void woosh_main_menu(void);
void woosh_black_box(const int destination_rect[]);
bool dir_exists(const char *path);
void dir_create(const char *path);
int load_highscore(const char *filepath);
void save_highscore(const char *filepath, int score);
void clean_up(void);

#endif // FUNCTIONS_H
