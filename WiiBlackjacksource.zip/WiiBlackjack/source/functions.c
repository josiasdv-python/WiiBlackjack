#include "functions.h"

//Function definitions
void set_pos(int row, int column) {
    printf("\033[%d;%dH", row, column);
}

// Create funtion to count items in a pointer array
int count_array(const char **arr) {
    int count = 0;
    if (arr == NULL) return 0;
    while (arr[count] != NULL) {
        count++;
    }
    return count;
}

// Create a function that receives an empty deck
void new_deck(Card temp_deck[52]) {
	const char *card_rank[] = {
		"Ace", "2", "3", "4", "5", "6", "7",
		"8", "9", "10", "Jack", "Queen", "King"
	};

	const char *card_suit[] = {
		"Hearts", "Diamonds", "Clubs", "Spades"
	};
	
	// Create the deck
	int i = 0;
	for (int rank = 0; rank < 13; rank++) {
		for (int suit = 0; suit < 4; suit++) {
			temp_deck[i].rank = card_rank[rank];
			temp_deck[i].suit = card_suit[suit];
			i++;
		}
	}
}

// Create a function for whenever cards are low
void fresh_deck(void) {
	
	// Needed for random cards
	srand((unsigned int)time(NULL));
	
	if (num_of_decks >= 1) {
		// Put deck_a into deck
		for (int i = 0; i < 52; i++) {
			deck[i] = deck_a[i];
		}
		// Shuffle deck (Fisher-Yates)
		for (int i = 51; i > 0; i--) {
			int j = rand() % (i + 1);
			Card temp = deck[i];
			deck[i] = deck[j];
			deck[j] = temp;
		}
		top_card_of_deck = 51;
	}
	if (num_of_decks >= 2) {
		// Put deck_b into deck
		int x = 52;
		for (int i = 0; i < 52; i++) {
			deck[x] = deck_b[i];
			x++;
		}		
		// Shuffle deck (Fisher-Yates)
		for (int i = 103; i > 0; i--) {
			int j = rand() % (i + 1);
			Card temp = deck[i];
			deck[i] = deck[j];
			deck[j] = temp;
		}
		top_card_of_deck = 103;	
	}
	if (num_of_decks >= 3) {
		// Put deck_c into deck
		int x = 104;
		for (int i = 0; i < 52; i++) {
			deck[x] = deck_c[i];
			x++;
		}	
		// Shuffle deck (Fisher-Yates)
		for (int i = 155; i > 0; i--) {
			int j = rand() % (i + 1);
			Card temp = deck[i];
			deck[i] = deck[j];
			deck[j] = temp;
		}
		top_card_of_deck = 155;
	}
	if (num_of_decks >= 4) {
		// Put deck_d into deck
		int x = 156;
		for (int i = 0; i < 52; i++) {
			deck[x] = deck_d[i];
			x++;
		}		
		// Shuffle deck (Fisher-Yates)
		for (int i = 207; i > 0; i--) {
			int j = rand() % (i + 1);
			Card temp = deck[i];
			deck[i] = deck[j];
			deck[j] = temp;
		}
		top_card_of_deck = 207;
	}
	card_count_running = 0;
}

// Define function card value
int card_value(Card card) {
	if (strcmp(card.rank, "Jack") == 0) return 10;
	if (strcmp(card.rank, "Queen") == 0) return 10;
	if (strcmp(card.rank, "King") == 0) return 10;
	if (strcmp(card.rank, "Ace") == 0) return 11;
	return atoi(card.rank);
}

// Define function count value
int count_value(Card card) {
    if (strcmp(card.rank, "10") == 0) return -1;
	if (strcmp(card.rank, "Jack") == 0) return -1;
	if (strcmp(card.rank, "Queen") == 0) return -1;
	if (strcmp(card.rank, "King") == 0) return -1;
	if (strcmp(card.rank, "Ace") == 0) return -1;
	if (strcmp(card.rank, "7") == 0) return 0;
	if (strcmp(card.rank, "8") == 0) return 0;
	if (strcmp(card.rank, "9") == 0) return 0;
    return 1;
}

// Function to setup the vertex descriptor for sprites
void setup_vertex(void) {
	GX_ClearVtxDesc();	
	GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
	GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);	
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XY, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);
	GX_SetNumChans(1);
	GX_SetNumTexGens(1);
	GX_SetTevOp(GX_TEVSTAGE0, GX_REPLACE);
	GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
	GX_SetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);
}

// Function to draw the sprite quad texture
void draw_sprite_tex(int x, int y, int width, int height) {	
	GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
		GX_Position2f32(x, y);					// Top Left
		GX_TexCoord2f32(0.0, 0.0);
		GX_Position2f32(x + width, y);			// Top Right
		GX_TexCoord2f32(1.0, 0.0);
		GX_Position2f32(x + width, y + height);	// Bottom Right
		GX_TexCoord2f32(1.0, 1.0);
		GX_Position2f32(x, y + height);			// Bottom Left
		GX_TexCoord2f32(0.0, 1.0);
	GX_End();									// Done Drawing The Quad
}

// Function to draw the rotated sprite quad texture
void draw_sprite_rotate(int x, int y, int width, int height) {	
	GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
		GX_Position2f32(x + width, y);			// Top Right
		GX_TexCoord2f32(0.0, 0.0);
		GX_Position2f32(x + width, y + height);	// Bottom Right
		GX_TexCoord2f32(1.0, 0.0);
		GX_Position2f32(x, y + height);			// Bottom Left
		GX_TexCoord2f32(1.0, 1.0);
		GX_Position2f32(x, y);					// Top Left
		GX_TexCoord2f32(0.0, 1.0);
	GX_End();									// Done Drawing The Quad
}

// Funtion to draw card at rectangle
void draw_card(Card card, const int rect[]) {
	if (strcmp(card.suit, "Hearts") == 0) {
		if (strcmp(card.rank, "Jack") == 0) TPL_GetTexture(&spriteTPL,HeartsJack,&texObj);
		if (strcmp(card.rank, "Queen") == 0) TPL_GetTexture(&spriteTPL,HeartsQueen,&texObj);
		if (strcmp(card.rank, "King") == 0) TPL_GetTexture(&spriteTPL,HeartsKing,&texObj);
		if (strcmp(card.rank, "Ace") == 0) TPL_GetTexture(&spriteTPL,HeartsAce,&texObj);
		if (strcmp(card.rank, "2") == 0) TPL_GetTexture(&spriteTPL,Hearts2,&texObj);
		if (strcmp(card.rank, "3") == 0) TPL_GetTexture(&spriteTPL,Hearts3,&texObj);
		if (strcmp(card.rank, "4") == 0) TPL_GetTexture(&spriteTPL,Hearts4,&texObj);
		if (strcmp(card.rank, "5") == 0) TPL_GetTexture(&spriteTPL,Hearts5,&texObj);
		if (strcmp(card.rank, "6") == 0) TPL_GetTexture(&spriteTPL,Hearts6,&texObj);
		if (strcmp(card.rank, "7") == 0) TPL_GetTexture(&spriteTPL,Hearts7,&texObj);
		if (strcmp(card.rank, "8") == 0) TPL_GetTexture(&spriteTPL,Hearts8,&texObj);
		if (strcmp(card.rank, "9") == 0) TPL_GetTexture(&spriteTPL,Hearts9,&texObj);
		if (strcmp(card.rank, "10") == 0) TPL_GetTexture(&spriteTPL,Hearts10,&texObj);
	}
	if (strcmp(card.suit, "Diamonds") == 0) {
		if (strcmp(card.rank, "Jack") == 0) TPL_GetTexture(&spriteTPL,DiamondsJack,&texObj);
		if (strcmp(card.rank, "Queen") == 0) TPL_GetTexture(&spriteTPL,DiamondsQueen,&texObj);
		if (strcmp(card.rank, "King") == 0) TPL_GetTexture(&spriteTPL,DiamondsKing,&texObj);
		if (strcmp(card.rank, "Ace") == 0) TPL_GetTexture(&spriteTPL,DiamondsAce,&texObj);
		if (strcmp(card.rank, "2") == 0) TPL_GetTexture(&spriteTPL,Diamonds2,&texObj);
		if (strcmp(card.rank, "3") == 0) TPL_GetTexture(&spriteTPL,Diamonds3,&texObj);
		if (strcmp(card.rank, "4") == 0) TPL_GetTexture(&spriteTPL,Diamonds4,&texObj);
		if (strcmp(card.rank, "5") == 0) TPL_GetTexture(&spriteTPL,Diamonds5,&texObj);
		if (strcmp(card.rank, "6") == 0) TPL_GetTexture(&spriteTPL,Diamonds6,&texObj);
		if (strcmp(card.rank, "7") == 0) TPL_GetTexture(&spriteTPL,Diamonds7,&texObj);
		if (strcmp(card.rank, "8") == 0) TPL_GetTexture(&spriteTPL,Diamonds8,&texObj);
		if (strcmp(card.rank, "9") == 0) TPL_GetTexture(&spriteTPL,Diamonds9,&texObj);
		if (strcmp(card.rank, "10") == 0) TPL_GetTexture(&spriteTPL,Diamonds10,&texObj);
	}
	if (strcmp(card.suit, "Clubs") == 0) {
		if (strcmp(card.rank, "Jack") == 0) TPL_GetTexture(&spriteTPL,ClubsJack,&texObj);
		if (strcmp(card.rank, "Queen") == 0) TPL_GetTexture(&spriteTPL,ClubsQueen,&texObj);
		if (strcmp(card.rank, "King") == 0) TPL_GetTexture(&spriteTPL,ClubsKing,&texObj);
		if (strcmp(card.rank, "Ace") == 0) TPL_GetTexture(&spriteTPL,ClubsAce,&texObj);
		if (strcmp(card.rank, "2") == 0) TPL_GetTexture(&spriteTPL,Clubs2,&texObj);
		if (strcmp(card.rank, "3") == 0) TPL_GetTexture(&spriteTPL,Clubs3,&texObj);
		if (strcmp(card.rank, "4") == 0) TPL_GetTexture(&spriteTPL,Clubs4,&texObj);
		if (strcmp(card.rank, "5") == 0) TPL_GetTexture(&spriteTPL,Clubs5,&texObj);
		if (strcmp(card.rank, "6") == 0) TPL_GetTexture(&spriteTPL,Clubs6,&texObj);
		if (strcmp(card.rank, "7") == 0) TPL_GetTexture(&spriteTPL,Clubs7,&texObj);
		if (strcmp(card.rank, "8") == 0) TPL_GetTexture(&spriteTPL,Clubs8,&texObj);
		if (strcmp(card.rank, "9") == 0) TPL_GetTexture(&spriteTPL,Clubs9,&texObj);
		if (strcmp(card.rank, "10") == 0) TPL_GetTexture(&spriteTPL,Clubs10,&texObj);
	}
	if (strcmp(card.suit, "Spades") == 0) {
		if (strcmp(card.rank, "Jack") == 0) TPL_GetTexture(&spriteTPL,SpadesJack,&texObj);
		if (strcmp(card.rank, "Queen") == 0) TPL_GetTexture(&spriteTPL,SpadesQueen,&texObj);
		if (strcmp(card.rank, "King") == 0) TPL_GetTexture(&spriteTPL,SpadesKing,&texObj);
		if (strcmp(card.rank, "Ace") == 0) TPL_GetTexture(&spriteTPL,SpadesAce,&texObj);
		if (strcmp(card.rank, "2") == 0) TPL_GetTexture(&spriteTPL,Spades2,&texObj);
		if (strcmp(card.rank, "3") == 0) TPL_GetTexture(&spriteTPL,Spades3,&texObj);
		if (strcmp(card.rank, "4") == 0) TPL_GetTexture(&spriteTPL,Spades4,&texObj);
		if (strcmp(card.rank, "5") == 0) TPL_GetTexture(&spriteTPL,Spades5,&texObj);
		if (strcmp(card.rank, "6") == 0) TPL_GetTexture(&spriteTPL,Spades6,&texObj);
		if (strcmp(card.rank, "7") == 0) TPL_GetTexture(&spriteTPL,Spades7,&texObj);
		if (strcmp(card.rank, "8") == 0) TPL_GetTexture(&spriteTPL,Spades8,&texObj);
		if (strcmp(card.rank, "9") == 0) TPL_GetTexture(&spriteTPL,Spades9,&texObj);
		if (strcmp(card.rank, "10") == 0) TPL_GetTexture(&spriteTPL,Spades10,&texObj);
	}

	GX_LoadTexObj(&texObj,GX_TEXMAP0);
	if (rotate_flag) draw_sprite_rotate(rect[0], rect[1], rect[3] - 16, rect[2] + 12);
	else draw_sprite_tex(rect[0], rect[1], rect[2], rect[3]);
}

// Funtion to draw back
void draw_card_back(const int rect[]) {
	TPL_GetTexture(&spriteTPL,CardBack,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(rect[0], rect[1], rect[2], rect[3]);
}

// Function to draw the correct strategy
void draw_strategy(const int rect[]) {
	if (num_of_decks == 1) TPL_GetTexture(&spriteTPL,BasicStrategy1Deck,&texObj);
	if (num_of_decks == 2) TPL_GetTexture(&spriteTPL,BasicStrategy2Deck,&texObj);
	if (num_of_decks == 3) TPL_GetTexture(&spriteTPL,BasicStrategy3Deck,&texObj);
	if (num_of_decks == 4) TPL_GetTexture(&spriteTPL,BasicStrategy4Deck,&texObj);
	
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(rect[0], rect[1], rect[2], rect[3]);
}

// Funtion to draw the table
void draw_table(const int rect[]) {
	TPL_GetTexture(&spriteTPL,TableGreen,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(rect[0], rect[1], rect[2], rect[3]);
}

// Draw the button or mask but after getting texture
void draw_button_mask(const int rect[]) {
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(rect[0], rect[1], rect[2], rect[3]);
}

// Define function to draw the player pointer
void draw_player_pointer(void) {
	TPL_GetTexture(&spriteTPL,MouseCursor,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(ir.x, ir.y, 40, 50);
}

// Define function fill screen main menu
void fill_screen_main_menu(void) {
    
	// Draw the Blackjack font at start of game
	TPL_GetTexture(&spriteTPL,BlackjackWord,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);		
	draw_sprite_tex(110, 50, 220, 90);
	
	// Draw the strategy and table
	draw_strategy(basic_rect);
	draw_table(table_green_rect);
	
    // Draw the buttons but after getting button textures
	TPL_GetTexture(&spriteTPL,NewGame_Button,&texObj);
	draw_button_mask(new_button_rect);
	TPL_GetTexture(&spriteTPL,TableRules_Button,&texObj);
	draw_button_mask(rules_button_rect);
	TPL_GetTexture(&spriteTPL,Options_Button,&texObj);
	draw_button_mask(options_button_rect);
	TPL_GetTexture(&spriteTPL,About_Button,&texObj);
	draw_button_mask(about_button_rect);
	TPL_GetTexture(&spriteTPL,Quit_Button,&texObj);
	draw_button_mask(quit_button_rect);
}

// Define function fill screen for betting
void fill_screen_bet(void) {
	
	// Draw the strategy and table
	draw_strategy(basic_rect);
	draw_table(table_green_rect);
	
    // Draw the buttons but after getting button textures
	TPL_GetTexture(&spriteTPL,Bet10_Button,&texObj);
	draw_button_mask(bet10_button_rect);
	TPL_GetTexture(&spriteTPL,Bet25_Button,&texObj);
	draw_button_mask(bet25_button_rect);
	TPL_GetTexture(&spriteTPL,Bet50_Button,&texObj);
	draw_button_mask(bet50_button_rect);
	TPL_GetTexture(&spriteTPL,Bet100_Button,&texObj);
	draw_button_mask(bet100_button_rect);
	TPL_GetTexture(&spriteTPL,Bet250_Button,&texObj);
	draw_button_mask(bet250_button_rect);
}

// Define function fill screen for blackjack
void fill_screen_buttons(void) {
	
	// Draw the strategy and table
	draw_strategy(basic_rect);
	draw_table(table_green_rect);
	
    // Draw the buttons but after getting button textures
	TPL_GetTexture(&spriteTPL,Stand_Button,&texObj);
	draw_button_mask(stand_button_rect);
	TPL_GetTexture(&spriteTPL,Hit_Button,&texObj);
	draw_button_mask(hit_button_rect);
	TPL_GetTexture(&spriteTPL,Double_Button,&texObj);
	draw_button_mask(double_button_rect);
	TPL_GetTexture(&spriteTPL,Triple_Button,&texObj);
	draw_button_mask(triple_button_rect);
	TPL_GetTexture(&spriteTPL,Split_Button,&texObj);
	draw_button_mask(split_button_rect);
}

// Define function fill screen for insurance
void fill_screen_insurance(void) {
	
	// Draw the strategy and table
	draw_strategy(basic_rect);
	draw_table(table_green_rect);
	
	// Draw the buttons but after getting button textures
	TPL_GetTexture(&spriteTPL,Yes_Button,&texObj);
	draw_button_mask(yes_button_rect);
	TPL_GetTexture(&spriteTPL,No_Button,&texObj);
	draw_button_mask(no_button_rect);
}

// Define function fill screen for options
void fill_screen_options(void) {
	
	// Draw the strategy and table
	draw_strategy(basic_rect);
	
	// Draw the buttons but after getting button textures
	TPL_GetTexture(&spriteTPL,Confirm_Button,&texObj);
	draw_button_mask(confirm_button_rect);
	TPL_GetTexture(&spriteTPL,Default_Button,&texObj);
	draw_button_mask(default_button_rect);
	TPL_GetTexture(&spriteTPL,Cancel_Button,&texObj);
	draw_button_mask(cancel_button_rect);
	
	// Draw the selection circles
	TPL_GetTexture(&spriteTPL,SelectionBlack,&texObj);
	draw_button_mask(deck1_circle);
	draw_button_mask(deck2_circle);
	draw_button_mask(deck3_circle);
	draw_button_mask(deck4_circle);
	draw_button_mask(slow_circle);
	draw_button_mask(medium_circle);
	draw_button_mask(fast_circle);
	draw_button_mask(on_circle);
	draw_button_mask(off_circle);
}

// Define function woosh
void woosh(const int destination_rect[]) {
	int temp_rect[] = {middle_rect[0] << 4, -80 << 4, card_rect[2], card_rect[3]};
	int x = ((destination_rect[0] << 4) - temp_rect[0]) / animation_speed;
	int y = ((destination_rect[1] << 4) - temp_rect[1]) / animation_speed;
	
	TPL_GetTexture(&spriteTPL,CardBack,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);

	while (temp_rect[1] <= destination_rect[1] << 4) {
		
		draw_sprite_tex(temp_rect[0] >> 4, temp_rect[1] >> 4, card_rect[2], card_rect[3]);
		
		temp_rect[0] += x;
		temp_rect[1] += y;

		GX_DrawDone();
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
	}
}

// Define woosh for main menu
void woosh_main_menu(void) {
	int temp_rect[] = {middle_rect[0] << 4, -80 << 4, card_rect[2] << 4, card_rect[3] << 4};
	int x = ((basic_rect[0] << 4) - temp_rect[0]) / (animation_speed + 5);
	int y = ((basic_rect[1] << 4) - temp_rect[1]) / (animation_speed + 5);
	int xx = ((basic_rect[2] << 4) - temp_rect[2]) / (animation_speed + 5);
    int yy = ((basic_rect[3] << 4) - temp_rect[3]) / (animation_speed + 5);

	if (num_of_decks == 1) TPL_GetTexture(&spriteTPL,BasicStrategy1Deck,&texObj);
	if (num_of_decks == 2) TPL_GetTexture(&spriteTPL,BasicStrategy2Deck,&texObj);
	if (num_of_decks == 3) TPL_GetTexture(&spriteTPL,BasicStrategy3Deck,&texObj);
	if (num_of_decks == 4) TPL_GetTexture(&spriteTPL,BasicStrategy4Deck,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);

	while (temp_rect[0] <= basic_rect[0] << 4) {
				
		draw_sprite_tex(temp_rect[0] >> 4, temp_rect[1] >> 4, temp_rect[2] >> 4, temp_rect[3] >> 4);
		
		temp_rect[0] += x;
		temp_rect[1] += y;
		temp_rect[2] += xx;
        temp_rect[3] += yy;
		
		GX_DrawDone();		
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
	}
}

// Define woosh for black box
void woosh_black_box(const int destination_rect[]) {
	int temp_rect[] = {middle_rect[0] << 4, -80 << 4, card_rect[2] << 4, card_rect[3] << 4};
	int x = ((destination_rect[0] << 4) - temp_rect[0]) / (animation_speed + 5);
	int y = ((destination_rect[1] << 4) - temp_rect[1]) / (animation_speed + 5);
	int xx = ((destination_rect[2] << 4) - temp_rect[2]) / (animation_speed + 5);
    int yy = ((destination_rect[3] << 4) - temp_rect[3]) / (animation_speed + 5);

	TPL_GetTexture(&spriteTPL,TextureBlack,&texObj);
	GX_LoadTexObj(&texObj,GX_TEXMAP0);

	while (temp_rect[1] <= destination_rect[1] << 4) {
				
		draw_sprite_tex(temp_rect[0] >> 4, temp_rect[1] >> 4, temp_rect[2] >> 4, temp_rect[3] >> 4);
		
		temp_rect[0] += x;
		temp_rect[1] += y;
		temp_rect[2] += xx;
        temp_rect[3] += yy;
		
		GX_DrawDone();		
		GX_CopyDisp(xfb, GX_FALSE);
		VIDEO_WaitVSync();
	}
}

// Define check for whether a directory exists at the specified path
bool dir_exists(const char *path) {
    struct stat st;
    return (stat(path, &st) == 0 && S_ISDIR(st.st_mode));
}

// Define create a directory path function
void dir_create(const char *path) {
    char tmp_path[256];
    snprintf(tmp_path, sizeof(tmp_path), "%s", path);
    size_t len = strlen(tmp_path);

    // Strip trailing slash if present so path parsing stays consistent
    if (len > 0 && tmp_path[len - 1] == '/') tmp_path[len - 1] = '\0';

    // Walk through the path string to create intermediate parent directories
    for (char *p = tmp_path + 1; *p; p++) {
        if (*p == '/') {
			
            // Temporarily truncate string at the current slash
			*p = '\0';

            // Skip root drive letters ("sd:") and create missing folders
            if (*(p - 1) != ':' && !dir_exists(tmp_path)) {
                if (mkdir(tmp_path, 0777) != 0) return;
            }
			
			// Restore slash and continue
            *p = '/';
        }
    }

    // Create the final target directory if it still doesn't exist
    if (!dir_exists(tmp_path)) {
        if (mkdir(tmp_path, 0777) != 0) return;
    }

    return;
}

// Reads the saved integer high score from disk and returns 0 if the file cannot be read
int load_highscore(const char *filepath) {
    FILE *fp = fopen(filepath, "r");
    if (!fp) return 0;
    int score = 0;
    fscanf(fp, "%d", &score);
    fclose(fp);
    return score;
}

// Writes the current high score to disk in plain text
void save_highscore(const char *filepath, int score) {
    FILE *fp = fopen(filepath, "w");
    if (!fp) return;
    fprintf(fp, "%d\n", score);
    fclose(fp);
    return;
}

// Define clean up function
void clean_up(void) {
	if (MP3Player_IsPlaying()) MP3Player_Stop();
	ASND_End();
	WPAD_Shutdown();
	GX_DrawDone();
	GX_Flush();
	fflush(NULL);
	fatUnmount("sd:/");
	fatUnmount("usb:/");
	VIDEO_WaitVSync();
	exit(0);
}
